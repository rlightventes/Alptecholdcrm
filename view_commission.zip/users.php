<?php include'header.php';?>
<script src="Flexible.Pagination.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
 <style>
        .hide{display: none;}
        body { background-color: #fafafa; }
        .container { margin: 10px auto; }
    </style>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-xs-12 col-sm-1">
							<h4 class="page-title">Users</h4>
							
						</div>
						<div class="col-sm-6">
						     <form method="post" action="">
    					    <div class="col-xs-6 col-sm-4">
    					            <select class="form-control col-sm-4" name="sel_state" id="sel_state">
    					                <option value="">Select State</option>
    					                <?php 
    					                $mysqli->orderBy('state1','asc');
    					                $mysqli->groupBy('state1');
    									$getSate = $mysqli->get(USER);
    									foreach ($getSate as $allState) {
    									    if(!empty($allState['state1'])):
    					                ?>
    					                <option value="<?=$allState['state1']?>"><?=$allState['state1']?></option>
    					                <?php endif; } ?>
    					            </select>
    					    </div>
    					     <div class="col-xs-6 col-sm-4">
    					            <select class="form-control col-sm-4" name="sel_city">
    					                <option value="">Select City</option>
    					                <?php 
    					                $mysqli->orderBy('city1','asc');
    					                $mysqli->groupBy('city1');
    									$getCity = $mysqli->get(USER);
    									foreach ($getCity as $allState) {
    									    if(!empty($allState['city1'])):
    					                ?>
    					                <option value="<?=$allState['city1']?>"><?=$allState['city1']?></option>
    					                <?php endif; } ?>
    					            </select>
    					    </div>
    					     <div class="col-xs-6 col-sm-4">
    					           <button type="submit" class="btn btn-primary" name="search">Search</button>
    					    </div>
					    </form>
						</div>
						<div class="col-xs-12 col-sm-5 text-right m-b-30">
							<a href="usersHide.php" class="btn btn-primary pull-right rounded" style="margin-left:10px"><i class="fa fa-eye-slash"></i> Hide</a>
							<a href="add-clients.php" class="btn btn-primary pull-right rounded"  style="margin-left:10px"><i class="fa fa-plus"></i> Add Users</a>
								<form method="post" action="export-clients.php">
						    <?php 	if(isset($_POST['search'])){ ?> 
						    <input type="hidden" name="sel_state" value="<?=$_POST['sel_state']?>" />
						    <input type="hidden" name="sel_city" value="<?=$_POST['sel_city']?>" />
						    <?php }?>
     <input type="submit" name="export" class="btn btn-primary rounded" value="Export to Excel" />
    </form>
							
						</div>
						<!--<div class="col-sm-1">-->
						<!--	<button class="btn btn-primary rounded pull-right" onclick="myFunction()"><i class="fa fa-plus"></i> Filters</button>-->
						<!--</div>-->
					</div>
					<div class="row">
					    
					</div>
					<div style="clear:both"></div>
					<!--<div id="filter">-->
     <!--               	<form action="" method="post">-->
     <!--           			<table class="table table-striped">-->
     <!--           				<tr >-->
     <!--               				<td colspan="" width="20%">-->
     <!--                 					<select class="form-control" name="search_from" id="search_from" >-->
     <!--                   					<option value="Search for">Search for</option>-->
     <!--                   					<option value="id">User Id</option>-->
     <!--                   					<option value="name">User Name</option>-->
     <!--                   					<option value="email">Email</option>-->
     <!--                   					<option value="mobile">Mobile</option>-->
     <!--                   					<option value="product">Product</option>-->
     <!--                   					<option value="assigned_staff">Assigned Staff</option>-->
     <!--                   					<option value="created">Created</option>-->
     <!--                   					<option value="status">Status</option>-->
     <!--                 					</select>-->
     <!--               				</td>-->
     <!--               				<td colspan="2" width="15%">-->
     <!--                 					<select class="form-control" name="search_type" id="type" style="display: block;">-->
     <!--                   					<option>Select Search Type</option>-->
     <!--                   					<option value="LIKE">Start with</option>-->
     <!--                   					<option value="LIKE">End with</option>-->
     <!--                   					<option value=">=">Min</option>-->
     <!--                   					<option value="<=">Max</option>-->
     <!--                   					<option value="=">Equal</option>-->
     <!--                 					</select>-->
     <!--                 					<p id="msg"></p>-->
     <!--               				</td>-->
     <!--               				<td width="30%">-->
     <!--               					<div id="canId"><input class="form-control" type="text" name="search_value"></div>-->
     <!--               				</td>-->
     <!--               				<td width="10%" style="border: none; text-align: center;" >-->
     <!--               					<div>                   						-->
     <!--               					<input type="submit" class="btn btn-success btn-block" name="rangetwo" value="SEARCH">-->
     <!--               					</div>-->
     <!--               				</td>-->
     <!--               			</tr>-->
     <!--               			<tr>-->
     <!--               			</tr>-->
     <!--               		</table>-->
     <!--               	</form>-->
					<!--</div>-->
					<div class="row" id="desktop_view">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table m-b-0" id="example">
									<thead>
										<tr>
									    <th  id="ifd" style="display:none">&nbsp;</th>
										<th id="ifd" >#</th>
										<th id="ifd" >Date</th>
										<th id="ifd" >Company Name</th>
										<th id="ifd">Contact Person</th>
										<th id="ifd" >Phone</th>
										<th id="ifd" >State</th>
										<th id="ifd" >City</th>
										<th id="ifd" >Assigned Staff</th>
										<th id="ifd" >Category</th>
										<th id="ifd" >Lead Type</th>
										<th class="text-right">Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php 
								
										$sr = '1';
								// 		if($getAdmin['profile_type'] != 'Admin'):
								// 		    $mysqli->where('assign', $getAdmin['id']);
								// 		endif;
										if(isset($_POST['search'])):
										    $mysqli->where('state1', $_POST['sel_state']);
										    $mysqli->where('city1', $_POST['sel_city']);
										 endif;
							
								    $mysqli->orderBy('created_date', 'desc');
									$getLeads = $mysqli->get(USER);
								// 	echo "<pre>";
								// 		echo $enq_date;
								// 	echo date('d-M-Y', $enq_date);
								// 	print_r($getLeads);
								
									foreach ($getLeads as $getUser) {
									extract($getUser);
									$product = base64_encode($id);
									$date1 = strtotime($created_date);  
								// 	$date1 = $enq_date;  
									$lead = base64_encode($id); 
                                    $primary_id = str_pad($id, 3, '0', STR_PAD_LEFT);
                                    $expAssign = explode(',', $getUser['assign_to']);
                                  if($hide != 1){ 	
                                   ?>
										<tr>
										<td style="display:none"><?=$created_date?></td>    
										<td>CLT-<?=$primary_id?></td>
										<td><?=date('d-M-Y', $date1)?></td>
										<td style="text-transform:capitalize"><?=$getUser['company_name']?></td>
										<td style="text-transform:capitalize"><?=$getUser['fname']?> <?=$getUser['lname']?></td>
										<td><?=$getUser['contact1']?></td>
										<td><?=$getUser['state1']?></td>
										<td><?=$getUser['city1']?></td>
										<td><?php 
										    foreach($expAssign  as $asgNos){
												$mysqli->where('id', $asgNos);
												$getEmp = $mysqli->getOne(UADMIN);
												
												echo $getEmp['fname']." ".$getEmp['lname']." ";
										    }
											?>
										</td>
										<td><?=$reg?></td>
										<td><?=$lead_type?></td>
											
											
											<td class="text-right">
												<div class="dropdown">
													<a href="profile.php?client=<?=$lead?>" class="text-success size15"><i class="fa fa-table"></i></a> &nbsp; &nbsp;
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="add-clients.php?lead=<?=$lead?>"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_employee" data-id="<?=$id?>" class="delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr>
										<?php
										} 
										
										}?>
										
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="row staff-grid-row" id="mobile_view">
						<input class="searchBox form-control" placeholder="Search Something...">
            			<div id="content">
            				<?php 
								foreach ($getLeads as $getUser) {
									extract($getUser);
									$product = base64_encode($id);
									$date1 = strtotime($created_date);  
									$lead = base64_encode($id); 
                                    $primary_id = str_pad($id, 3, '0', STR_PAD_LEFT);
                                    $expAssign = explode(',', $getUser['assign_to']);
                                   if($hide != 1){ 
										?>
						<div class="col-md-4 col-sm-4 col-xs-12 col-lg-3 result well">
							<div class="profile-widget">
							    <h4 class="user-name m-t-10 m-b-0 text-ellipsis">
									CLT-<?=$primary_id?>
								</h4>
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
									<?=date('d-M-Y', $date1)?>
								</h5><br>
								
								<div class="profile-img">
									<a href="profile.php?client=<?=$client?>" class="avatar"><?=substr($getUser['company_name'],0,1);?></a>
								</div>
									<h4 class="user-name m-t-10 m-b-0 text-ellipsis">
									<?=$getUser['company_name']?>
								</h4>
								<h4 class="user-name m-t-10 m-b-0 text-ellipsis">
									
									<!--<a class="small" href="https://api.whatsapp.com/send?phone=91<?=$contact1?> &text=Hello <?=$fname?> <?=$lname?>" data-action="share/whatsapp/share" target="_blank" class="font-size-18">-->
									<!--	<i class="fa fa-whatsapp" style="background: #0b8902;padding: 10px;border-radius: 11%;color: #fff;"></i>-->
									<!--</a>-->
									<a class="small" href="tel:<?=$contact1?>">
										<i class="fa fa-phone" style="background: #0b8902;padding: 10px;border-radius: 11%;color: #fff;"></i>
									</a>
									<a class="small" href="mailto:<?=$email?>">
										<i class="fa fa-envelope" style="background: #0b8902;padding: 10px;border-radius: 11%;color: #fff;"></i>
									</a>
									
								</h4><br>
								<div class="dropdown profile-action">
									<a href="profile.php?client=<?=$lead?>" class=" btn-default btn-sm m-t-10 m-l-5">
									    <i style="color: #55ce63;font-size: 20px;" class="fa fa-table"></i>
								    </a>
									
								</div>
							
							
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
									<?=$getUser['fname']?> <?=$getUser['lname']?>
								</h5>
							
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
								    Assigned Staff<br>
									<?php 
										    foreach($expAssign  as $asgNos){
												$mysqli->where('id', $asgNos);
												$getEmp = $mysqli->getOne(UADMIN);
												
												echo $getEmp['fname']." ".$getEmp['lname']." ";
										    }
											?>
								</h5>
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
									Category: <?=$reg?>
								</h5>
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
									Lead Type: <?=$lead_type?>
								</h5>
								
							</div>
						</div>
						<?php } }?>
						</div>
						<div class="clearfix"></div>
						<div id="pagingControls"></div>
            			<div id="showingInfo" class="well" style="margin-top:20px"></div>
					</div>
				<?php include'messages.php';?>
            </div>
				<div id="delete_employee" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content modal-md">
							<div class="modal-header">
								<h4 class="modal-title">Delete Leads</h4>
							</div>
							<form method="post" action="ajax.php?action=delete">
								<input type="hidden" name="id" value="" id="del_id" >
								<input type="hidden" name="tab_name" value="<?=USER?>" >
								<input type="hidden" name="col_nam" value="id" >
								<input type="hidden" name="loc" value="users.php" >
								<div class="modal-body card-box">
									<p>Are you sure want to delete this?</p>
									<div class="m-t-20"> <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
										<button type="submit" class="btn btn-danger">Delete</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
        	</div>
        </div>
		<?php include'footer.php';?>
		<script type="text/javascript">
			$('.delete').click(function(){
				var id = $(this).attr('data-id');
				$('#del_id').val(id);
				//alert(id);
			})
		</script>
		<script>
            $(function() {
                var flexiblePagination = $('#content').flexiblePagination({
                    itemsPerPage : 10,
                    itemSelector : 'div.result:visible',
                    pagingControlsContainer : '#pagingControls',
                    showingInfoSelector : '#showingInfo',
                    css: {
                        btnNumberingClass: 'btn btn-sm btn-success',
                        btnFirstClass: 'btn btn-sm btn-success',
                        btnLastClass: 'btn btn-sm btn-success',
                        btnNextClass: 'btn btn-sm btn-success',
                        btnPreviousClass: 'btn btn-sm btn-success'
                    }
                });
                flexiblePagination.getController().onPageClick = function(pageNum, e){
                    console.log('You Clicked Page: '+pageNum)
                };
                // Direct JS Object method of using the FlexiblePagination
                //        var pager = new Flexible.Pagination();
                //        pager.itemsPerPage = 1;
                //        pager.pagingContainer = '#content';
                //        pager.itemSelector = 'div.result:visible';  //That is, Select and paginate only the filtered visible '.result' div.
                //        pager.pagingControlsContainer = '#pagingControls';
                //        pager.showCurrentPage();
            });
        </script>