<?php
	include_once '../common.php';
	include_once 'smsapi.php';
	include_once '../API/noti_API.php';

	extract($_POST);
	extract($_GET);
    $username = base64_decode($user);
    $password = base64_decode($pw);
    
	$mysqli->where('email', $username);
				$mysqli->where('password', $password);
				$login = $mysqli->getOne(UADMIN);
				if(isset($login)):
					 if(!empty($remeber)) {
				        setcookie ("member_login",$username,time()+ (10 * 365 * 24 * 60 * 60));
				       setcookie ("member_pass",$password,time()+ (10 * 365 * 24 * 60 * 60));
			        } else {
        				if(isset($_COOKIE["member_login"])) {
        					setcookie ("member_login","");
        				}
        				if(isset($_COOKIE["member_pass"])) {
        					setcookie ("member_pass","");
        				}
			        }
				    
					$_SESSION['user'] = $username;
					$_SESSION['user_id'] = $login['id'];
				// 	if(!empty($pageDirect)):
				// 	   header('location:tasks.php');
				// 	else:
				// $client = base64_encode($login['id']);
					    header('location:add-task.php?task='.$task.'&client='.$client);
					    
				// 	endif;
					
				else:
					header('location:index.php?textMsg=fail');
				endif;
	?>