<?php include 'header.php';?>

<?php 
$mysqli->where('service_no', $_GET['serviceNo']);
$getCommision = $mysqli->getOne(COMM);
$client = base64_encode($getCommision['client_id']);
$mysqli->where('id', $getCommision['client_id']);
$getUser = $mysqli->getOne(USER);
$mysqli->where('id', $getUser['assign_to']);
$getEmp = $mysqli->getOne(UADMIN);
?>
<div class="page-wrapper">
   <div class="content container-fluid">
      <div class="row">
         <div class="col-sm-4 col-xs-3">
            <h4 class="page-title">New Commisioning</small></h4>
         </div>
         <div class="col-sm-8 col-xs-9 text-right m-b-20">
            <a href="commission_list.php?client=<?=$client?>" class="btn btn-primary rounded"><i class="fa fa-list" aria-hidden="true"></i> Back</a>
            
              <a href="convert_commission.php?serviceNo=<?=$_GET['serviceNo']?>" class="btn btn-primary rounded" target="_blank"><i class="fa fa-pdf" aria-hidden="true"></i> Generate PDF</a>
         </div>
      </div>
      <form method="post" action="ajax.php?action=commission">
      <div class="row">
         <div class="panel panel-body">
            <!--<div class="col-md-12 text-center">-->
             
            <!--  <b>ALPTECH INTERNATIONAL PVT LTD</b></br>-->
            <!--  <b>Plot A-231, road no 21, Y Lane Wagle Industrial Area, Thane - 400 604</b><br/><br>-->
            <!--  <br>-->
            <!--</div>-->
            <br/><br/>
            <div class="col-md-12 text-center"> <img src="assets/img/alp_logo.png" width="200"><br/><br/></div>
            <div class="col-md-4 text-left">
                <?php if(!empty($getData['com_name'])){?>  <b><?=$getData['com_name']?></b></br> <?php } ?>
	            <?php if(!empty($getData['co_name'])){?>    <b><?=$getData['co_name']?></b></br> <?php } ?>
	            <?php if(!empty($getData['address'])){?>    <b>Address:</b> <?=$getData['address']?></br> <?php } ?>
	            <?php if(!empty($getData['tel_no'])){?>    <b>Telephone No.:</b> <?=$getData['tel_no']?></br> <?php } ?>
	            <?php if(!empty($getData['email_id'])){?>    <b>Email.:</b> <?=$getData['email_id']?></br> <?php } ?>
	            <?php if(!empty($getData['web_address'])){?>   <b>Web.:</b> <?=$getData['web_address']?></br <?php } ?>
	            <?php if(!empty($getData['pan_no'])){?>   <b>PAN:</b> <?=$getData['pan_no']?> <?php } ?> <?php if(!empty($getData['gst_no'])){?> | <b>GST No.:</b> <?=$getData['gst_no']?><?php } ?>
               
                
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4 text-left">
                <b>To, </b><br/><b><?=$getUser['fname'].' '.$getUser['lname']?></b></br>  
               <b><?=$getUser['company_name']?></b></br>
               <b>Address:</b> <?=$getUser['address1']?></br>
               <?=$getUser['city1']?> <?=$getUser['state1']?> <?=$getUser['country1']?><br/>
               <b>Mobile No. :</b> <?=$getUser['contact1']?></br><b>Email. :</b> <?=$getUser['email']?><br/>
               <?php if(!empty($getUser['gst'])) { ?>
               <b>GST No. :</b> <?=$getUser['gst']?>
               <?php } ?>
               <input type="hidden" value="<?=$getUser['id']?>" name="client_id" />
            </div>
            <div style="clear:both"></div>
             <br/>
            <div class="col-md-8 text-left">
                <p><b></b>Service Report No:</b> <?=$getCommision['service_no']?>
               <br>
               <b>Service Type:</b> 
               <?php  if($getCommision['commission'] == '1'){ ?>
              &nbsp; &bull; Commissioning
                <?php }?>
                <?php  if($getCommision['amc'] == '1'){ ?>
                &nbsp; &bull; AMC
                 <?php }?>
                <?php  if($getCommision['service_breakdown'] == '1'){ ?>
                 &nbsp; &bull; Service/Breakdown
                 <?php }?>
                <?php  if($getCommision['inspect_gen'] == '1'){ ?>
               &nbsp; &bull;  Inspection/General
               <?php }?>
                
                 
            </div>
            <div class="col-md-4 text-left">
                
                <p><b>Complaint Date:</b> <?=$getCommision['complaint_date']?><br/>
                <b>Complaint No:</b> <?=$getCommision['complaint_no']?></p>
                
                
            </div>
            <div class="clearfix"></div>
        
            <div class="col-md-12" id="overflow ">
                <div id="desktop_view">
              <table class="table table-bordered table-hover" >
                <thead>
                  <tr>
                    <th style="background: #000; color: #fff" class="text-center"> #No </th>
                    <th style="background: #000; color: #fff; text-align: center">Machine Type</th>
                    <th style="background: #000; color: #fff; text-align: center">Machine Name</th>
                    <th style="background: #000; color: #fff">Remark</th>
                  </tr>
                </thead>
                <tbody id="wrapper1">
                 <?php 
                    $sr = "1";
                    $mysqli->where('service_no', $_GET['serviceNo']);
                    $getService = $mysqli->get(COMM);
                    foreach($getService as $services){
                        extract($services);
                 ?>
                  <tr  >
                    <td><?=$sr++?></td>
                    <td><?=$machine_type?></td>
                    <td><?=$machine_name?></td>
                    <td><?=$remark?></td>
                  </tr>
                </tbody>
                <?php } ?>
              </table>
</div>
            </div>
            <div style="clear:both"></div><br/>
            <div class="col-md-12" id="mobile_view">
                <?php 
                    $sr = "1";
                    $mysqli->where('service_no', $_GET['serviceNo']);
                    $getService = $mysqli->get(COMM);
                    foreach($getService as $services){
                        extract($services);
                 ?>
                 <p><b><?=$sr++?>. Machine Type: </b> <?=$machine_type?></p>
                 <p><b>Machine Name: </b> <?=$machine_name?></p>
                 <p><b>Remark: </b> <?=$remark?></p>
                 <hr/>
                <?php } ?>
            </div>
                <div class="col-md-12">
                  <b>Work Carried Out: </b> <?=$work_carried?>
                </div>
                <div style="clear:both"></div><br/>
            <div class="col-md-12">
              <b>Engineer's Recommendations: </b> <?=$recommendations	?>
            </div>
                 <div style="clear:both"></div><br/>
            <div class="col-md-12">
                 <label><b>Spares Used (if any): </b></label>
                 <div id="mobile_view">
                     <p><b>Engineer Attended:</b>  <?=$attendance?></p>
                     <p><b>No of Days taken:</b> <?=$no_days?></p>
                     <p><b>Date of Attendance:</b> <?=$attendance?></p>
                     <p><b>Invoice Number:</b> <?=$invoice_no?></p>
                     <p><b>Mode of travel:</b> <?=$mode_travel?></p>
                     <p><b>Invoice Date: </b> <?=$invoice_date?></p>
                     <p><b>Mode of Kms:</b> <?=$mode_kms?></p>
                     <p><b>Amount Payable:</b> <?=$amt?></p>
                 </div>
                 <div id="desktop_view">
              <table class="table table-stripped">
                <tbody>
                  <tr>
                    <td width="50%"><b>Engineer Attended:</b>  <?=$attendance?></td>
                    <td width="50%"><b>No of Days taken:</b> <?=$no_days?></td>
                  </tr>
                  <tr>
                    <td width="50%"><b>Date of Attendance:</b> <?=$attendance?></td>
                    <td width="50%"><b>Invoice Number:</b> <?=$invoice_no?></td>
                  </tr>
                  <tr>
                    <td width="50%"><b>Mode of travel:</b> <?=$mode_travel?></td>
                    <td width="50%"><b>Invoice Date: </b> <?=$invoice_date?></td>
                  </tr>
                  <tr>
                    <td width="50%"><b>Mode of Kms:</b> <?=$mode_kms?></td>
                    <td width="50%"><b>Amount Payable:</b> <?=$amt?></td>
                  </tr>
                </tbody>
              </table>
              </div>
            </div>
            <div style ="clear:both"></div><br/>
            <div class="col-md-12">
              <label>Customers Feedback</label>
             <?=$feedback?>
            </div>
             <div style ="clear:both"></div><br/>
            <div class="col-md-12">
              <label>Comments:</label><br/>
              <?=$comments?>
              <br>
            </div>
            <div class="clearfix"></div><br/><br/><br/><br/><br/><br/>
            <div  id="desktop_view">
           <div class="col-md-6">
              <label>Engineer Sign</label>
              <br/>
              <br/>
              <br>
            </div>
            
            <div class="col-md-6 text-right">
              <label>Customer Signature & Stamp</label>
              <br/>
              <br/>
              <br>
            </div>
            </div>
            <div  id="mobile_view">
           <div class="col-md-6 text-center">
              <label>Engineer Sign</label>
              <br/>
              <br/>
              <br>
            </div>
            
            <div class="col-md-6 text-center">
              <label>Customer Signature & Stamp</label>
              <br/>
              <br/>
              <br>
            </div>
            </div>
            
         </div>
      </div>
      </form>
   </div>
   <?php include 'messages.php';?>
</div>
</div>
<?php include 'footer.php';?>
<script>
    $(document).ready(function() {
    var max_fields1 = 10; //Maximum allowed input fields 
    var wrapper1    = $("#wrapper1"); //Input fields wrapper
    var add_button1 = $("#add_fields1"); //Add button class or ID
	var x1 = 1; //Initlal input field is set to 1
	
	//When user click on add input button
	$(add_button1).click(function(e){
        e.preventDefault();
		//Check maximum allowed input fields
        if(x1 < max_fields1){ 
            x1++; //input field increment
			 //add input field
            $(wrapper1).append('<tr><td>'+x1+'</td><td><input type="text" name="machine_type[]"  placeholder="Enter Machine Type" class="form-control"/></td><td><input type="text" name="machine_name[]" placeholder="Enter Machine Name" class="form-control qty" step="0" min="0"/></td><td><input type="text" name="remark[]" placeholder="Remark" class="form-control" /></td></tr>');
        }
    });
	
    //when user click on remove button
    $(wrapper1).on("click","#remove_field1", function(e){ 
        e.preventDefault();
		$(this).parent('div').remove(); //remove inout fieldx--; //inout field decrement
    })
});

</script>
</script>
