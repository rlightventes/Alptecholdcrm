<?php include 'header.php'?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						 <?php
							$client = base64_decode($_GET['client']);
							$mysqli->where('id', $client);
							$getUser = $mysqli->getOne(USER);
							$mysqli->where('id', $getUser['assign_to']);
							$getEmp = $mysqli->getOne(UADMIN);
						?>
						<div class="col-sm-8">
							<h4 class="page-title">Leads  - <?=$getUser['company_name']; ?> <a href="profile.php?client=<?=$_GET['client']?>" class="text-success size15"><i class="fa fa-table"></i></a></h4> 
							<h5><i class="fa fa-user"></i> <?=$getUser['fname'].' '.$getUser['lname']?> | <i class="fa fa-mobile"></i> <?=$getUser['contact1']; ?> |  Assign to: <?=$getEmp['fname']." ".$getEmp['lname']?></h5>
						</div>
						<div class="col-sm-4 text-right">
						       <a href="taskHide.php?client=<?=$_GET['client']?>" class="btn btn-primary pull-right rounded" style="margin-left:10px"><i class="fa fa-eye-slash"></i> Hide</a>
						    	<!--<a href="task_hidelist.php?client=<?=$_GET['client']?>" class="btn btn-primary rounded" ><i class="fa fa-list"></i> Unhide</a> -->
						    <a class="btn btn-primary rounded pull-right" href="add-task.php?client=<?=$_GET['client']?>">New Task</a>
						</div>
					
						<!--<div class="col-sm-1">-->
						<!--	<button class="btn btn-primary rounded pull-right" onclick="myFunction()"><i class="fa fa-list"></i> Filters</button>-->
						<!--</div>-->
						<!--<div class="col-sm-1">-->
						<!--	<a href="export_to_xl.php" class="btn btn-primary rounded pull-right"><i class="fa fa-plus"></i> Export</a>-->
						<!--</div>-->
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
										    <th id="ifd" style="display:none"></th>
											<th id="ifd" width="7%">Task Id</th>
											<th id="ifd">Task Date</th>
											<th id="ifd" width="20%">Task</th>
											<th id="ifd">Assign Team</th>
											<th id="ifd">Start Date</th>
											<th id="ifd">End Date</th>
											<th id="ifd">Created</th>
											<th id="ifd">Priority</th>
											<th id="ifd">Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
									    <?php 
									  $mysqli->where('client', $client);
									  $mysqli->groupBy('task');
									  $getTask = $mysqli->get(TASK);
									  foreach($getTask as $taskAll)
									  {
									  $task = base64_encode($taskAll['task_id']);
									  if($taskAll['complete_task'] == '1'){
									      $statusName = 'Working';
									  }elseif($taskAll['complete_task'] == '2'){
									      $statusName = 'Complete';
									  }elseif($taskAll['complete_task'] == '3'){
									      $statusName = 'Pending';
									  }elseif($taskAll['complete_task'] == '4'){
									      $statusName = 'Overdue';
									  }else{
									      $statusName = 'New';
									  }
									  if($taskAll['hide'] != "1"){
									    ?>
									    <tr>
									        <td style="display:none"><?=$taskAll['task_id']?></td>
									        <td style="vertical-align:top"><a href="task_view.php?task=<?=$task?>&client=<?=$_GET['client']?>">TSK-<?=$taskAll['task_id']?></a></td>
									        <td style="vertical-align:top"><?=date('d/m/Y', strtotime($taskAll['created_date']));?></td>
									        <td style="vertical-align:top"><?=$taskAll['task']?></td>
									        <td style="text-transform:capitalize">
									     <?php 
									     $mysqli->where('task_id', $taskAll['task_id']);
									     $empName = $mysqli->get(TASK);
									     foreach($empName as $nameEmp){
								$mysqli->where('id', $nameEmp['employee_list']);
							    $nameUser = $mysqli->getOne(UADMIN);
							    if(!empty($nameUser['fname'])){
									        echo "<p>- ".$nameUser['fname']." ".$nameUser['lname']."</p>";
									     }}
									     
									     ?>
									        </td>
									        <td style="vertical-align:top"><?=date('d/m/Y',strtotime($taskAll['start_date']))?></td>
									        <td style="vertical-align:top"><?=date('d/m/Y',strtotime($taskAll['end_date']))?></td>
									        <td style="vertical-align:top">
									    <?php 
								$mysqli->where('id', $taskAll['createTask']);
							    $createUser = $mysqli->getOne(UADMIN); 
							    echo $createUser['fname']." ".$createUser['lname'];
									       ?>          
									            
									        </td>
									        <td style="vertical-align:top">
									          <?=$taskAll['priority']?>
									        </td>
									        <td ><?=$statusName?></td>
									        <td class="text-right" >

												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>

													<ul class="dropdown-menu pull-right">
														<li></li>
														<li><a href="add-task.php?task=<?=$task?>&client=<?=$_GET['client']?>" ><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_project" data-id="<?=$taskAll['task_id']?>" class="delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
													</ul>
												</div>
											</td>
									    </tr>
									    <?php } } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				<?php include 'messages.php'?>
            </div>
			<div id="delete_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
							<div class="modal-header">
								<h4 class="modal-title">Delete Leads</h4>
							</div>
							<form method="post" action="ajax.php?action=delete">
								<input type="hidden" name="id" value="" id="del_id" >
								<input type="hidden" name="tab_name" value="<?=TASK?>" >
								<input type="hidden" name="col_nam" value="task_id" >
								<input type="hidden" name="loc" value="task_list.php?client=<?=$_GET['client']?>" >
								<div class="modal-body card-box">
									<p>Are you sure want to delete this?</p>
									<div class="m-t-20"> <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
										<button type="submit" class="btn btn-danger">Delete</button>
									</div>
								</div>
							</form>
						</div>
				</div>
			</div>
        </div>
        <script type="text/javascript">
			$('.delete').click(function(){
				var id = $(this).attr('data-id');
				$('#del_id').val(id);
				//alert(id);
			})
		</script>
        <script type="text/javascript">
   $('#genderType').hide();
    $('#dateView').hide();
  $('#product_typeType').hide();
  $('#stageID').hide();
  $('#brandType').hide();
  $('#priorityType').hide();
  $("#search_from").change(function(){
  var selectVal = $(this).val();
  //alert(selectVal);


if(selectVal == 'id' || selectVal == 'name' || selectVal == 'leader' || selectVal == 'status' || selectVal == 'team' || selectVal == 'priority'){
  $('#type').html("<select class='form-control' name='search_type'><option value='='>Equal</option></select>");
}
else if( selectVal == 'deadline' ){
   $('#type').html("<select class='form-control' name='search_type'><option value='>='>Min </option><option value='<='>Max</option></select>");
}
if(selectVal == 'id' || selectVal == 'name' || selectVal == 'team' || selectVal == 'purchase_rate' || selectVal == 'leader'){
  $('#canId').html('<input class="form-control" type="text" name="search_value">');
}
else if(selectVal == 'deadline'){
    $('#canId').html('<input class="form-control datetimepicker" type="date"  name="search_value" >');
}
else if(selectVal == 'status'){
    $('#canId').html("<select class='form-control' name='search_value' ><option>Select Status</option><option value='Active'>Active</option><option value='Inactive'>Inactive</option></select>");
}
else if(selectVal == 'priority'){
    $("#canId").html("<select class='form-control' name='search_value' id='priorityType'><option>Select Priority</option><option value='high'><i class='fa fa-dot-circle-o text-danger'></i>High</option><option value='medium'>Medium</option><option value='low'>Low</option></select>"); 
}
  });
</script>
<?php include 'footer.php'?>