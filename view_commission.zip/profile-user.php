<?php include 'header.php';?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8">
							<h4 class="page-title">Employee Profile</h4>
						</div>
						<div class="col-sm-4 text-right m-b-30">
						    <?php if(!isset($_GET['myprofile'])) { ?>
							<a href="add-employees.php?id=<?=$_GET['user']?>" class="btn btn-primary rounded"><i class="fa fa-plus"></i> Edit Profile</a>
							<?php } ?>
						</div>
					</div>
					<?php 
					$id = base64_decode($_GET['user']);
					$mysqli->where('id', $id);
					$getUser = $mysqli->getOne(UADMIN);
					extract($getUser);
					$primary_id = str_pad($id, 3, '0', STR_PAD_LEFT);
					?>
					<div class="card-box m-b-0">
						<div class="row">
							<div class="col-md-12">
								<div class="profile-view">
									<div class="profile-img-wrap">
										<div class="profile-img">
											<a href="#"><img class="avatar" src="assets/img/user.jpg" alt=""></a>
										</div>
									</div>
									<div class="profile-basic">
										<div class="row">
											<div class="col-md-8">
												<div class="profile-info-left col-md-6">
													<div class="text-muted">Employee ID : EMP-<?=$primary_id?></div>
													<h3 class="user-name m-t-0"><?=$fname.' '.$lname?></h3>
													<div class="text-muted">Designation : <?=$profile_type?> </div>
													<div class="text-muted">Department : <?=$designation?></div>
													
													<br/>
													<h5 class="company-role m-t-0 m-b-1"><span><b>Mobile: </b></span><?=$mobile_no?></h5>
													<h5 class="company-role m-t-0 m-b-1"><span><b>Email:</b> </span><?=$email?></h5>
													
												</div>
												
											</div>

											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>	
				</div>
            </div>
        </div>
        <script type="text/javascript">
            function show(str){
            	document.getElementById('sh3').style.display = 'none';
                document.getElementById('sh2').style.display = 'none';
                document.getElementById('sh1').style.display = 'block';
            }
            function show2(sign){
            	document.getElementById('sh3').style.display = 'none';
                document.getElementById('sh2').style.display = 'block';
                document.getElementById('sh1').style.display = 'none';
            }
            function show3(sign){
            	document.getElementById('sh3').style.display = 'block';
                document.getElementById('sh2').style.display = 'none';
                document.getElementById('sh1').style.display = 'none';
            }
        </script>
    <?php include 'footer.php';?>