<?php include 'header.php';?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4 col-xs-3">
              <?php 
              if(isset($_GET['lead'])):
                $lead = base64_decode($_GET['lead']);
                $mysqli->where('id', $lead);
                $getEnq = $mysqli->getOne(ENQ);
                $type = 'new'; 
                $product_id = $getEnq['product_id'];
                $client_id = $getEnq['client_id']; 
                $enqDate = date('Y-m-d', strtotime($getEnq['created_date']));

                $mysqli->where('id', $client_id);
                $getUser = $mysqli->getOne(USER);
                $address = $getUser['address1'];

                $mysqli->where('id', $product_id);
                $getProduct = $mysqli->getOne(PRODUCT);

                $product_name = $getProduct['name']; 
                $description = $getProduct['description']; 
                $specification = $getProduct['specification']; 
                $mrp = $getProduct['mrp']; 
                $mep = $getProduct['sale_rate']; 
                $product_weight = $getProduct['product_weight']; 
                $product_dimension = $getProduct['product_dimension']; 
                $discount = ''; 


              
                $co_name = (!empty($getEnq['company_name']))? $getEnq['company_name'] : $getUser['company_name'] ;         
                $mobile_no =  (!empty($getEnq['contact']))? $getEnq['email'] : $getUser['contact1'] ;
                $email = (!empty($getEnq['email']))? $getEnq['email'] : $getUser['email'] ;
                $type_of_industry = $getEnq['type_of_industry'];
                $sub_type1 = $getEnq['sub_type1'];
                $sub_type2 = $getEnq['sub_type2'];
                $material_type = $getEnq['material_type'];
                $type_of_cutting = $getEnq['type_of_cutting'];
                $quantum_of_cutting = $getEnq['quantum_of_cutting'];
                $length = $getEnq['length'];
                $breadth = $getEnq['breadth'];
                $weight = $getEnq['weight'];
                $height = $getEnq['height'];
                $thickness = $getEnq['thickness'];
                $setup_type = $getEnq['setup_type'];
                $existing_machine = $getEnq['existing_machine'];
                $quotation_date = date('d/m/Y', time());
                $editID = '';
                $terms_conditions = '<ul>
                        <li><span style="font-weight: normal;">Payment: 100% advance.</span></li>
                        <li><span style="font-weight: normal;">Installation/commisioning/training of the machine extra. Accomodation to be provided by the Client during installation.Minimum 3 star stay.</span></li>
                        <li><span style="font-weight: normal;">Freight forwarding extra from mumbai.</span></li>
                        <li><span style="font-weight: normal;">Warranty period-12 months for spares 12 months for service.</span></li>
                        <li><span style="font-weight: normal;">Packaging: standard with thermo retractable plastic film, suitable for transport by container.</span></li>
                        <li><span style="font-weight: normal;">Delivery- Immediate.</span></li>
                        <li><span style="font-weight: normal;">Wooden packing extra.</span></li>
                        <li><span style="font-weight: normal;">GST@18%:as applicable.</span></li>
                        <li><span style="font-weight: normal;">All Import duties included.</span></li>
                        <li>Note: <span style="font-weight: normal;">above prices are ex mumbai. It includes all import taxes.</span></li>
                        <li>Validity :<span style="font-weight: normal;"> 4 weeks</span></li>
                      </ul>
                      <p>&nbsp; &nbsp; &nbsp; &nbsp;Bank Detail: IDBI Bank,<br>&nbsp; &nbsp; &nbsp; &nbsp;Branch: Chembur,<br>&nbsp; &nbsp; &nbsp; &nbsp;A/C Name: Mengi Engineering Company,<br>&nbsp; &nbsp; &nbsp; &nbsp;A/C No.: 0018102000029777<br>&nbsp; &nbsp; &nbsp; &nbsp;IFSC Code: IBKL0000018</p>';
              elseif(isset($_GET['qtID'])):
                $id = base64_decode($_GET['qtID']);
                $mysqli->where('id', $id);
                $getEnq = $mysqli->getOne(QOT);
                $editID = $id;
                $type = 'update'; 
                $co_name = $getEnq['company_name'];
                $address = $getEnq['address'];
                $mobile_no = $getEnq['mobile_no'];
                $email = $getEnq['email'];
                $enqDate = $getEnq['enquiry_date'];
                $lead = $getEnq['enquiry_id'];
                $product_id = $getEnq['product_id'];
                $client_id = $getEnq['client_id']; 
                $product_name = $getEnq['product_name']; 
                $description = $getEnq['description']; 
                $specification = $getEnq['specification']; 
                $mrp = $getEnq['mrp']; 
                $mep = $getEnq['mep']; 
                $product_weight = $getEnq['product_weight']; 
                $product_dimension = $getEnq['product_dimension']; 
                $terms_conditions = $getEnq['terms_conditions']; 
                   $discount = $getEnq['discount'];

                $mysqli->where('id', $lead);
                $product = $mysqli->getOne(ENQ);

                $type_of_industry = $product['type_of_industry'];
                $sub_type1 = $product['sub_type1'];
                $sub_type2 = $product['sub_type2'];
                $material_type = $product['material_type'];
                $type_of_cutting = $product['type_of_cutting'];
                $quantum_of_cutting = $product['quantum_of_cutting'];
                $length = $product['length'];
                $breadth = $product['breadth'];
                $weight = $product['weight'];
                $height = $product['height'];
                $thickness = $product['thickness'];
                $setup_type = $product['setup_type'];
                $existing_machine = $product['existing_machine'];
                $quotation_date = date('d/m/Y', strtotime($getEnq['quotation_date']));
              
              endif;
            if($type_of_industry == 'Cutting Operation'):
                  $display = 'block';
                else:
                  $display = 'none';
                endif;
              $client = base64_encode($client_id);
            ?>
						          
            <h4 class="page-title">View Enq-<?=str_pad($lead, 3, '0', STR_PAD_LEFT)?><br/><small>Enq Date: <?=date('d-M-Y', strtotime($getEnq['created_date']))?></small></h4>
</div>    
						<div class="col-sm-8 col-xs-9 text-right m-b-20">
						<?php if(isset($_GET['lead'])): ?>
              <a href="enq_view.php?lead=<?=$_GET['lead']?>" class="btn btn-primary rounded"><i class="fa fa-list" aria-hidden="true"></i> Back</a>
            <?php endif;?>
							
						</div>
					</div>
					<div class="row">
						
					<form method="post" action="ajax.php?action=quote&type=<?=$type?>">
            <input type="hidden" name="editID" value="<?=$editID?>">
            <input type="hidden" name="enquiry_id" value="<?=$lead?>">
            <input type="hidden" name="enquiry_date" value="<?=$enqDate?>">
            <input type="hidden" name="product_id" value="<?=$product_id?>">
            <input type="hidden" name="client_id" value="<?=$client_id?>">
							<div class="col-md-4">
								<div class="form-group">
									<label class="control-label">Company Name </label>
                      <input type="text" value="<?=$co_name?>" class="form-control" name="company_name"/>
									
								</div>
							</div>
              <div class="col-md-4">
                <div class="form-group">
                  <label class="control-label">Email ID </label>
                  <input type="text" value="<?=$email?>" class="form-control" name="email"/>
                </div>
              </div>
              <div class="col-md-4">
                <div class="form-group">
                  
                  <label class="control-label">Contact </label>
                  <input type="text" value="<?=$mobile_no?>" class="form-control" name="mobile_no"/>
                </div>
              </div>
              <div class="col-md-12">
                <div class="form-group">
                  <label class="control-label">Address </label>
                  <input type="text" value="<?=$address?>" class="form-control" name="address"/>
                </div>
              </div>
							<div class="col-md-12">
								<div class="form-group">
									<label class="control-label">Product </label>
                 
                  <input type="text" value="<?=$product_name?>" name="product_name" class="form-control"/>
									
								</div>
							</div>

					    <div class="col-lg-12">
                  <div class="form-group">
                     <label>Description</label>
                     <textarea class="form-control" name="description" id="editor"><?=$description?></textarea>
                                       
                  </div>
                </div>
                <div class="col-lg-12">
                  <div class="form-group">
                     <label>Speicification</label>
                     <textarea class="form-control" name="specification" id="editor1"><?=$specification?></textarea>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="form-group">
                    <label>MRP</label>
                    <input type="text" value="<?=$mrp?>" class="form-control" id="mrp_amt" name="mrp"/>
                    
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="form-group">
                    <label>MEP</label>
                    <input disabled value="<?=$mep?>" name="mep" class="form-control"/>
                    
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="form-group">
                    <label>Weight</label>
                    <input type="text" value="<?=$product_weight?>" name="product_weight" class="form-control"/>
                    
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="form-group">
                    <label>Dimension</label>
                    <input type="text" value="<?=$product_dimension?>" name="product_dimension" class="form-control"/>
                    
                  </div>
                </div>

                <div class="col-lg-4">
                  <div class="form-group">
                    <label>Type of Industry</label>
                    <input disabled="" value="<?=$sub_type1?>" class="form-control"/>
                    
                  </div>
                </div>

                <div class="col-lg-4">
                  <div class="form-group">
                    <label>Type of Architecture</label>
                    <input disabled="" value="<?=$sub_type2?>" class="form-control"/>
                  </div>
                
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                    <label>Machine Type</label> 
                    <input disabled="" value="<?=$setup_type?>" class="form-control"/>
                  </div>
                </div>
                <div class="col-lg-3">
                  <div class="form-group">
                    <label>Existing Machines</label>
                    <input disabled="" value="<?=$existing_machine?>" class="form-control"/>
                  </div>
                </div>

                <div class="col-lg-3">
                  <div class="form-group">
                    <label>Type of Section</label>
                    <input disabled="" value="<?=$material_type?>" class="form-control"/>
                  </div>
                </div>   
                <div class="col-lg-3" id="cutt" >
                  <div class="form-group">
                    <label>Type of Cutting</label>
                    <input disabled="" value="<?=$type_of_cutting?>" class="form-control"/>
                  </div>
                </div>   
                <div class="col-lg-3" id="cutt1" >
                  <div class="form-group">
                    <label>Quantum of Cutting</label>
                    <input disabled="" value="<?=$quantum_of_cutting?>" class="form-control"/>
                  </div>
                </div>   
                <div style="clear: both"></div>
                <div class="col-lg-2"  id="hide">
                  <div class="form-group">
                    <label>Size of Profile <small>Length</small></label>
                    <input disabled="" value="<?=$length?>" class="form-control"/>
                  </div>
                </div>
                <div class="col-lg-1"   id="hide1">
                  <div class="form-group">
                    <label><small>Breadth</small></label>
                    <input disabled="" value="<?=$breadth?>" class="form-control"/>
                  </div>
                </div>
                  <div class="col-lg-1"   id="hide2">
                  <div class="form-group">
                  	<label><small>Height</small></label>
                    <input disabled="" value="<?=$height?>" class="form-control"/>
                  </div>
                </div>
                <div class="col-lg-1"   id="hide3">
                  <div class="form-group">
                    <label><small>Weight</small></label>
                    <input disabled="" value="<?=$weight?>" class="form-control"/>
                  </div>
                </div>
                <div class="col-lg-1"   id="hide4">
                  <div class="form-group">
                    <label><small>Thickness</small></label>
                    <input disabled="" value="<?=$thickness?>" class="form-control"/>
                  </div>
                </div>

                <div class="col-lg-3"   id="hide4">
                  <div class="form-group">
                    <label>Discount Amount</label>
                    <input type="text"  class="form-control" value="<?=$discount?>"  name="discount" />
                  </div>
                </div>
               <!--  <div class="col-lg-2"   id="hide4">
                  <div class="form-group">
                    <label>Discount %</label>
                    <input type="text" class="form-control" id="dis_per" name="dis_per" />
                  </div>
                </div> -->
                <div class="col-lg-3"   id="hide4">
                  <div class="form-group">
                    <label>Quotation Date</label>
                    <input type="text" id="datepicker" value="<?=$quotation_date?>" class="form-control datetimepicker" name="quotation_date" required="" />
                  </div>
                </div>
                <hr/>
                <div class="col-lg-12">
                  <div class="form-group">
                    <label>Terms and Condition</label>
                    <textarea class="form-control" name="terms_conditions" id="editor2">
                      <?=$terms_conditions?>
                    </textarea>
                    
                  </div>
                </div>
                <hr/>
                  <div class="col-lg-12">
                  <div class="form-group">
                  <button type="submit" class="btn btn-primary">SUBMIT</button>
							   </div>
               </div>
							
							
					</div>				
                </div>
				<?php include 'messages.php';?>
            </div>
        </div>

		<?php include 'footer.php';?>
    <script type="text/javascript">
      $("#dis_per").blur(function(){
        var dis_per = $(this).val();
        var mrp_amt = $("#mrp_amt").val().replace(/,/g, '');
        var amount = mrp_amt * dis_per / 100;
        var rAmt = Math.round(amount);
        $("#dis_amt").val(rAmt);
      });
       $("#dis_amt").blur(function(){
        var dis_amt = $(this).val().replace(/,/g, '');
        var mrp_amt = $("#mrp_amt").val().replace(/,/g, '');
        var amount = dis_amt * 100 / mrp_amt;
        var rAmt = Math.round(amount);
        $("#dis_per").val(rAmt);
      });
        $("#mrp_amt").blur(function(){
        var mrp_amt = $(this).val().replace(/,/g, '');
        var dis_per = $("#dis_per").val();
        var amount = mrp_amt * dis_per / 100;
        var rAmt = Math.round(amount);
        $("#dis_amt").val(rAmt);
      });
    </script>

	