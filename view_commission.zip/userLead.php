<?php include 'header.php';?>
<script src="Flexible.Pagination.js"></script>
<link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
 <style>
        .hide{display: none;}
        body { background-color: #fafafa; }
        .container { margin: 10px auto; }
    </style>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-8">
							<h4 class="page-title">Lead Type</h4>
						</div>
						<div class="col-sm-4 text-right m-b-30">
							<a href="add-userlead.php" class="btn btn-primary rounded" ><i class="fa fa-plus"></i> Add New Lead Type</a>
						</div>
					</div>
					<div class="row" id="desktop_view">
						<div class="col-md-12">
							<div>
								<table class="table table-striped custom-table m-b-0 datatable">
									<thead>
										<tr>
											<th>#</th>
											<th>Lead Type</th>
											<th>Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
											$sr = '1';
											$mysqli->orderBy('lead', 'asc');
											$getDepart = $mysqli->get(LEAD);
											foreach ($getDepart as $departVal) {
											$text = ($departVal['status'] == '1')? 'Active' : 'Inactive';
											$bg = ($departVal['status'] == '1')? 'success' : 'danger';
											$val = ($departVal['status'] == '1')? '0' : '1';
											if($departVal['hide'] != '1'):
												$loc = 'userLead.php';
												$tabName = LEAD;
												
										?>
										<tr>
											<td><?=$sr++?></td>
											<td><?=$departVal['lead']?></td>
											<td><a class="label label-<?=$bg?>" href="ajax.php?action=status&val=<?=$val?>&loc=<?=$loc?>&tabName=<?=$tabName?>&col_nam=id&id=<?=$departVal['id']?>"><?=$text?></a></td>
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="add-userlead.php?maincat=<?=$departVal['id']?>"  title="Edit"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_department" data-id="<?=$departVal['id']?>" title="Delete"  class="delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>

													</ul>
												</div>
											</td>
										</tr>
										<?php endif; } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
                <div class="row staff-grid-row" id="mobile_view">
						<input class="searchBox form-control" placeholder="Search Something...">
            			<div id="content">
            				<?php 
								foreach ($getDepart as $departVal) {
									$text = ($departVal['status'] == '1')? 'Active' : 'Inactive';
									$bg = ($departVal['status'] == '1')? 'success' : 'danger';
									$val = ($departVal['status'] == '1')? '0' : '1';
									if($departVal['hide'] != '1'):
										$loc = 'userLead.php';
										$tabName = LEAD; 
										?>
						<div class="col-md-4 col-sm-4 col-xs-12 col-lg-3 result well">
							<div class="profile-widget">
								<div class="profile-img">
									<a href="profile.php?client=<?=$client?>" class="avatar"><?=substr($departVal['lead'],0,1);?></a>
								</div>
								 <div class="dropdown profile-action">
									<a aria-expanded="false" class="action-icon dropdown-toggle" data-toggle="dropdown" href="">
										<i class="fa fa-ellipsis-v"></i>
									</a>
									<ul class="dropdown-menu pull-right">
										<li><a href="add-userlead.php?maincat=<?=$departVal['id']?>" title="Edit"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
										<li><a href="#" data-toggle="modal" data-target="#delete_department" data-id="<?=$departVal['id']?>" title="Delete"  class="delete"><i class="fa fa-trash-o m-r-5"></i> Delete</a></li>
									</ul>
								</div> 
								<h4 class="user-name m-t-10 m-b-0 text-ellipsis">
									<?=$departVal['lead']?>
								</h4>
								<h5 class="user-name m-t-10 m-b-0 text-ellipsis">
									<a style="color:#fff;" class="label label-<?=$bg?>" href="ajax.php?action=status&val=<?=$val?>&loc=<?=$loc?>&tabName=<?=$tabName?>&col_nam=id&id=<?=$departVal['id']?>"><?=$text?></a>
								</h5>
							</div>
						</div>
						<?php endif; }?>
						</div>
						<div class="clearfix"></div>
						<div id="pagingControls"></div>
            			<div id="showingInfo" class="well" style="margin-top:20px"></div>
					</div>
				<?php include 'messages.php';?>
            </div>
			<div id="delete_department" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Category</h4>
						</div>
						<form method="post" action="ajax.php?action=delete">
								<input type="hidden" name="id" value="" id="del_id" >
								<input type="hidden" name="tab_name" value="<?=LEAD?>" >
								<input type="hidden" name="col_nam" value="id" >
								<input type="hidden" name="loc" value="userLead.php" >
								<div class="modal-body card-box">
									<p>Are you sure want to delete this?</p>
									<div class="m-t-20"> <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
										<button type="submit" class="btn btn-danger">Delete</button>
									</div>
								</div>
						</form>
						
					</div>
				</div>
			</div>
        </div>
		<?php include 'footer.php';?>
		<script type="text/javascript">
			$('.delete').click(function(){
				var id = $(this).attr('data-id');
				$('#del_id').val(id);
			//	alert(id);
			})
		</script>
		<script>
            $(function() {
                var flexiblePagination = $('#content').flexiblePagination({
                    itemsPerPage : 10,
                    itemSelector : 'div.result:visible',
                    pagingControlsContainer : '#pagingControls',
                    showingInfoSelector : '#showingInfo',
                    css: {
                        btnNumberingClass: 'btn btn-sm btn-success',
                        btnFirstClass: 'btn btn-sm btn-success',
                        btnLastClass: 'btn btn-sm btn-success',
                        btnNextClass: 'btn btn-sm btn-success',
                        btnPreviousClass: 'btn btn-sm btn-success'
                    }
                });
                flexiblePagination.getController().onPageClick = function(pageNum, e){
                    console.log('You Clicked Page: '+pageNum)
                };
                // Direct JS Object method of using the FlexiblePagination
                //        var pager = new Flexible.Pagination();
                //        pager.itemsPerPage = 1;
                //        pager.pagingContainer = '#content';
                //        pager.itemSelector = 'div.result:visible';  //That is, Select and paginate only the filtered visible '.result' div.
                //        pager.pagingControlsContainer = '#pagingControls';
                //        pager.showCurrentPage();
            });
        </script>