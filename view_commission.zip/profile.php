<?php include 'header.php';?>
<?php 
	$id = base64_decode($_GET['client']);
	$client = base64_decode($_GET['client']);
	$mysqli->where('id', $id);
	$getUser = $mysqli->getOne(USER);
	extract($getUser);
	$primary_id = str_pad($id, 3, '0', STR_PAD_LEFT);
	$maturate = $getUser['maturate'];
	$mysqli->where('client_id', $client);
	$enqProduct = $mysqli->get(ENQ);
// 	$mysqli->where('hide', 0);
	$mysqli->where('client_id', $client);
	$mysqli->groupBy('quot_id');
	$getQt = $mysqli->get(QOT);
	$mysqli->groupBy('task');
	$mysqli->where('client', $client);
	$getTask = $mysqli->get(TASK);
	$mysqli->groupBy("service_no");
	$mysqli->where('client_id', $client);
	$getComm = $mysqli->get(COMM);
	$mysqli->where('clt_id', $client);
	$getCheck = $mysqli->get(CHECK);
	$mysqli->groupBy('check_id');
	$mysqli->where('clt_id', $client);
	$getList = $mysqli->get(AL_LIST);
	$mysqli->groupBy('pack_no');
	$mysqli->where('clt_id', $client);
	$getPriceList = $mysqli->get(AL_PRICE);
	$mysqli->where('client_id', $client);
	$getInv = $mysqli->get(INV);
	$mysqli->where('id', $assign_to);
	$assign = $mysqli->getOne(UADMIN);
	$gstAp = (!empty($gst_applicable))? $gst_applicable : 'No';
	$expAssign = explode(',', $assign_to);
?>

            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-xs-12 col-sm-2 col-md-2">
							<h4 class="page-title">View Profile  <br/> <small><b><?=$company_name?></b> {CLT-<?=$primary_id?>}</small><br/><small style="font-size: 12px"><?=$lead_type?></small></h4>
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
							<center>
								<a href="enq_list.php?client=<?=$_GET['client']?>" target="_blank" class="primeColor">
							<h2 class="counter"><?=count($enqProduct)?></h2> <small style="font-size: 10px;">Enquiry</small></a>
							</center>
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
							<center>
								<a href="qut_list.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getQt)?></h2> <small style="font-size: 10px;">Quote</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20  profile-info-right">
							<center>
								<a href="inv_list.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getInv)?></h2> <small style="font-size: 10px;">Invoice</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
							<center>
								<a href="task_list.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getTask)?></h2> <small style="font-size: 10px;">Task</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
							<center>
								<a href="commission_list.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getComm)?></h2> <small style="font-size: 10px;">Commission</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
						    <?php $sr= '0'; foreach($getCheck as $allCheck){  if($allCheck['hide'] == '1'){$sr++;}} ?>
							<center>
								<a href="checklist.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getCheck)-$sr?></h2> <small style="font-size: 10px;">DIE Checklist</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
						     <?php $srP= '0'; foreach($getPriceList as $allCheck){  if($allCheck['hide'] == '1'){$srP++;}} ?>
							<center>
								<a href="packlist.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getPriceList)-$srP?></h2> <small style="font-size: 10px;">Packing</small></a>
							</center>
							
						</div>
						<div class="col-xs-2 col-sm-2 col-md-1 m-b-20 profile-info-right">
							<?php $srCh= '0'; foreach($getList as $allCheck){  if($allCheck['hide'] == '1'){$srCh++;}} ?>
							<center>
								<a href="getcheckList.php?client=<?=$_GET['client']?>" class="primeColor">
							<h2 class="counter"><?=count($getList) - $srCh?></h2> <small style="font-size: 10px;">Checklist</small></a>
							</center>
							
						</div>
						<div class="col-xs-4 col-sm-2 col-md-2 text-right m-b-10">
							<a href="add-clients.php?lead=<?=$_GET['client']?>" class="btn btn-primary rounded"><i class="fa fa-plus"></i> Edit Profile</a>
						</div>
					</div>
					
					<div class="card-box m-b-0">
						<div class="row">
							<div class="col-md-12">
								<div class="profile-view">
									<div class="row">
										<div class="col-md-3">
											<div class="profile-info-left">
												<p><b><i class="fa fa-user"></i></b> <?=$fname.' '.$lname?></p>
												<p><b><i class="fa fa-mobile"></i></b> <?=$contact1?></p>
												<p><b><i class="fa fa-envelope"></i></b> <?=$email?></p>
												<p><b><i class="fa fa-map"></i></b> <?=$address1?></p>
												<p class="alert alert-warning">Assign To: <a href="?assign=assign&client=<?=$_GET['client']?>"><i class="fa fa-plus"></i></a><br/>
												
							
												<?php 
										    foreach($expAssign  as $asgNos){
												$mysqli->where('id', $asgNos);
												$getEmp = $mysqli->getOne(UADMIN);
												if(isset($getEmp)){
												echo "- ".$getEmp['fname']." ".$getEmp['lname']." <a class='remove' id='".$getEmp['id']."'><i class='fa fa-trash'></i></a><br/>";}
										    }
											?></p>
											<?php if(isset($_GET['assign'])){ ?>
											<div class="col-md-12">  
								    <form method="post" action="ajax.php?action=assign">			
								<div class="form-group">
								<input type="hidden" value="<?=$getUser['id']?>" name="id"/>
									<select class="select select2-hidden-accessible"  name="assign[]" <?=$required1?> multiple>
										
										<option value="">Select Assign Person</option>
										<?php 
										    $mysqli->orderBy('fname', 'desc');
											$getAssign = $mysqli->get(UADMIN);
											foreach ($getAssign as $assignMenu):
											  if($assignMenu['hide'] != '1'){ 
											 ?>
										<option value="<?=$assignMenu['id']?>"><?=$assignMenu['fname']." ".$assignMenu['lname']?></option>
									    <?php  } 
									    endforeach; ?>
									</select>
									    
								</div>
								<?php
								if(!empty($assign_to)){ ?>
									   <input type="hidden" value="<?=$assign_to?>" name="assList"/> 
									   <?php } ?>
								<button type="submit" class="btn btn-primary rounded">submit</button>
								</form>
								<br/><br/>
							</div>
									<?php }?>			<h6>Other Information</h6>
												<hr/>
												<?php if(!empty($contact2)):?>
												<p><b><i class="fa fa-mobile"></i></b> <?=$contact2?></p>
												<?php endif;?>
												<?php if(!empty($landline)):?>
												<p><b><i class="fa fa-phone"></i></b> <?=$landline?></p>
												<?php endif;?>
												<?php if(!empty($address2)):?>
												<p><b><i class="fa fa-map"></i></b> <?=$address2?></p>
												<?php endif;?>
												<?php if(!empty($address3)):?>
												<p><b><i class="fa fa-map"></i></b> <?=$address3?></p>
												<?php endif;?>
												<?php if(!empty($gst)):?>
												<p><b>GST No.</b> <?=$gst?></p>
												<?php endif;?>
												<?php if(!empty($tan)):?>
												<p><b>TAN No.</b> <?=$tan?></p>
												<?php endif;?>
												<?php if(!empty($vat)):?>
												<p><b>VAT No.</b> <?=$vat?></p>
												<?php endif;?> 
												<?php if(!empty($pan)):?>
												<p><b>PAN No.</b> <?=$pan?></p>
												<?php endif;?>
												<?php if(!empty($reg)):?>
												<p><b>Register No.</b> <?=$reg?></p>
												<?php endif;?> 	
												<?php if(!empty($ac_code)):?>
												<p><b>AC CODE</b> <?=$ac_code?></p>
												<?php endif;?>
												<?php if(!empty($group_code)):?>
												<p><b>Group CODE</b> <?=$group_code?></p>
												<?php endif;?> 
												<?php if(!empty($broker_code)):?>
												<p><b>Broker CODE</b> <?=$broker_code?></p>
												<?php endif;?> 
												<p><b>GST Applicable</b> <?=$gstAp?></p>
												<?php if(!empty($reg)):?>
												<p><b>Category</b> <?=$reg?></p>
												<?php endif;?> 
												<?php if(!empty($lead_type)):?>
												<p><b>Lead Type</b> <?=$lead_type?></p>
												<?php endif;?> 
											</div>
											
											<div>
												

											</div>

										</div>
										<div class="col-md-9 profile-info-right" >
												<form action="ajax.php?action=history" method="post" enctype="multipart/form-data" class="">
                    							<div class="row history_form">
                        							<div class="col-lg-12">
														<div class="form-group">
															<label class="radio-inline"><input type="radio" name="history_type" checked value="General"><strong>General</strong></label>
															<label class="radio-inline"><input type="radio" name="history_type" value="Call"><strong>Call</strong></label>
															<label class="radio-inline"><input type="radio" name="history_type" value="Meeting" ><strong>Meeting</strong></label>
															<label class="radio-inline"><input type="radio" name="history_type" value="Task"><strong>Task</strong> <a href="add-task.php?client=<?=$_GET['client']?>"> <i class="fa fa-plus"></i></a></label>
															<label class="radio-inline pull-right"><a href="history.php?client=<?=$_GET['client']?>">History</a></label>

            											</div>

            											<div style="clear:both"></div>
            											
            											<div class="form-group col-md-6" id="task_list" style="display: none; padding-left: 0">
            												<select class="form-control" name="task_list" id="task_list1">
            													<option value="">Select Task</option>
            						<?php 
            						$mysqli->where('client', $client);
            						$mysqli->groupBy('task');
            				// 		$mysqli->where('employee_list', $userGetID);
										$getTask = $mysqli->get(TASK);
																foreach ($getTask as $taskVal) { 
													if($taskVal['complete_task'] != '2' && $taskVal['hide'] != '1'){			
																?>
            													<option value="<?=$taskVal['task_id']?>"><?=$taskVal['task']?></option>
            												<?php } } ?>
            												</select>
            											</div>
            				<div class="form-group col-md-6" id="task_status" style="display: none; padding-left: 0">
            					<select class="form-control" name="task_status" id="task_status1">
            							<option value="">Working Status</option>
            							<option value="1">Working</option>
            							<option value="4">Overdue</option>
            							<option value="3">Pending</option>
            							<option value="2">Completed</option>
            					</select>
            				</div>
                            <div style="clear:both"></div>
            				<div class="form-group col-md-12" id="meet_fix" style="display: none; padding-left: 0">
            				      <input type="text" name="subject" class="form-control" placeholder="Enter Subject"><br/>
            					<label class="radio-inline">
								<input type="radio" name="meeting_type" value="1" > Meeting Fix </label>
								<label class="radio-inline">
                      			<input type="radio" name="meeting_type" value="2" > Meeting Update</label>
							</div>	
                      									
            				<input class="form-control datetimepicker" type="text" name="meeting_date" placeholder="Meeting Date" id="meet_date"  style="display: none;"><br/>
            											
            				<textarea class="form-control" name="comments" required="" placeholder="Enter Message" id="editor" ></textarea><br/>

														
                      		<div class="form-group col-md-6" style="padding-left: 0">
								<label>Attachment *</label><br>
								<input class="form-control" type="file" name="attachment" >
							    <span style="font-size: 10px;">(PDF, JEG, PNG, ZIP) Upto 5MB</span>
							</div>
							<div class="form-group col-md-6" style="padding-right: 0">
								<label>TBR </label> <small>(To be reminder)</small><br>
								<input class="form-control datetimepicker" type="text" name="reminder"  placeholder="Reminder Date">
							</div>
							<div style="clear: both;"></div>
								<label>To CC</label>
								<select class="select select2-hidden-accessible" name="emp[]" multiple=""  tabindex="-1" aria-hidden="true">
							<?php   $mysqli->where('status', '1');
								    $mysqli->orderBy('id', 'desc');
									$getEmp = $mysqli->get(UADMIN);
																	foreach ($getEmp as $empVal) {
																		extract($empVal);
																		if($hide != 1){
																	?>
																	<option 	 value="<?=$email?>"><?=$email?></option>
																	<?php } }?>
																	
																</select><br/><br/>
																<label><strong>To Client</strong></label>
																<label class="radio-inline">
																	<input type="radio" name="send_type" value="Email"> Email
																</label>
																<label class="radio-inline">
																	<input type="radio" name="send_type" value="SMS"> SMS
																</label>
																<label class="radio-inline">
																	<input type="radio" name="send_type" value="Both"> Both
																</label><label class="radio-inline">
																	<input type="radio" name="send_type" value="Null" checked=""> None
																</label><br/><br/>

											<label class="control-label">Maturate  Status</label>
		                      				<label class="radio-inline"><input type="radio" name="maturate" value="1" required <?php  if($maturate=='1'): echo 'checked'; endif;?>> Yes</label>
		                      				<label class="radio-inline"><input type="radio" name="maturate" value="0"  required <?php  if($maturate=='0'): echo 'checked'; endif;?>> No</label>
								
													</div>
													
												</div>
												<div class="row">
													<div class="col-md-12">
														<div class="staff-msg">
													<input type="hidden" name="client_id" value="<?=$client?>">
															<button type="submit" class="btn btn-custom">SUBMIT</button>
														</div>
													</div>
												</div>
												</form>
											
										</div>

									</div>




									
								</div>
							</div>
						</div>
					</div>	
					
                    
				</div>
				
            </div>
        </div>
        <div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog" style="margin-top: 120px">

    <!-- Modal content-->
    <div class="modal-content">
      
      <div class="modal-body">
      	<h3>Done !</h3>
        <p>History added successfully.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary close1" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<script>
	initSample();
</script>
        
    <?php include 'footer.php';?>
<?php if(isset($_GET['success'])):?>
	<script type="text/javascript">
		$('#myModal').modal('show'); 
	</script>

<?php endif; ?>
<script>
    $(".remove").click(function(){
        var assgnID = $(this).attr('id');
        var client = '<?=$_GET['client']?>';
        var action = "removeAssign";
        if (confirm("Are you sure?")) {
        
        $.ajax({
            type:"POST",
            url:"ajax.php",
            data:{assgnID:assgnID, client:client, action:action},
            success:function(data){
                window.location.href="profile.php?client=<?=$_GET['client']?>";
            }
        })
    }
    return false;
    })
</script>

    <script type="text/javascript">
    	$(".close1").click(function(){
    		window.location.href='profile.php?client=<?=$_GET['client']?>'
    	});
    	$("input[name='history_type']").click(function(){
    		var typeVal = $("input[name='history_type']:checked"). val();
    		 if(typeVal == 'Meeting'){
    			$("#meet_fix").css('display', 'block');
    			$("#meet_date").css('display', 'block');
    			$("#task_status").css('display', 'none');
    			$("#task_list").css('display', 'none');
    		}
    		else if(typeVal == 'Task'){
    			$("#task_status").css('display', 'block');
    			$("#task_list").css('display', 'block');
    			$('#meet_date').css('display', 'none');
    			$("#meet_fix").css('display', 'none');	
    		}else{
    			$('#meet_date').css('display', 'none');
    			$("#meet_fix").css('display', 'none');
    			$("#task_status").css('display', 'none');
    			$("#task_list").css('display', 'none');
    		}

    	});
    	
    
    </script>
    <script>
        $("#task_list1").change(function(){
           var taskID = $(this).val();
           var client = '<?=$client?>';
           var action = 'taskStaus';
           $.ajax({
               type:'POST',
               url:'ajax.php',
               data:{taskID:taskID, client:client, action:action},
               success:function(data){
                //   alert(data);
                 //  $("#task_status1").val(data);
                   
               }
           })
        })
    </script>