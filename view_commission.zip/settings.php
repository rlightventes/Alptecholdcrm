<?php include_once 'header.php';?>
<div class="page-wrapper">
    <div class="content container-fluid">
      
        <form method="post" action="ajax.php?action=setting" enctype="multipart/form-data">
		<div class="row">
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>Upload Logo</label>
					<input class="form-control" type="file" name="upload_file">
					<input type="hidden" value="<?=$getData['logo_img']?>" name="prv_logo"/>
					<?php if(!empty($getData['logo_img'])){ ?> <img src="assets/img/<?=$getData['logo_img']?>" width="100"> <?php } ?>
				</div>
		    </div>
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>Upload Favicon</label>
					<input class="form-control" type="file" name="upload_fav">
					<input type="hidden" value="<?=$getData['fav_img']?>" name="fav_logo"/>
					<small>Please upload favicon size 25 X 25 </small>
					<?php if(!empty($getData['fav_img'])){ ?> <img src="assets/img/<?=$getData['fav_img']?>"  width="30"> <?php } ?>
				</div>
		    </div>
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>Title Name</label>
					<input class="form-control" type="text" name="title_name" value="<?=$getData['title']?>">
				</div>
		    </div>
		    
		    <div style="clear:both"></div>
		    <div class="col-md-12 col-sm-12 col-lg-6">
		        <div class="form-group">
					<label>Company Name</label>
					<input class="form-control" type="text" name="com_name" value="<?=$getData['com_name']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-12 col-lg-6">
		        <div class="form-group">
					<label>C/o Company name</label>
					<input class="form-control" type="text" name="co_name" value="<?=$getData['co_name']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-12 col-lg-12">
		        <div class="form-group">
					<label>Address</label>
					<textarea class="form-control"  rows="4"  cols="5" name="address"><?=$getData['address']?></textarea>
				</div>
		    </div>
		    <div class="col-md-12 col-sm-12 col-lg-6">
		        <div class="form-group">
					<label>Telephone No.</label>
					<input class="form-control" type="text" name="tel_no" value="<?=$getData['tel_no']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-12 col-lg-6">
		        <div class="form-group">
					<label>Email</label>
					<input class="form-control" type="text" name="email_id" value="<?=$getData['email_id']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>Web</label>
					<input class="form-control" type="text" name="web_address" value="<?=$getData['web_address']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>PAN No.</label>
					<input class="form-control" type="text" name="pan_no" value="<?=$getData['pan_no']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-6 col-lg-4">
		        <div class="form-group">
					<label>GST No.</label>
					<input class="form-control" type="text" name="gst_no" value="<?=$getData['gst_no']?>">
				</div>
		    </div>
		    <div class="col-md-12 col-sm-12 col-lg-4">
		        <div class="form-group">
		            <label><br/><br/><br/></label>
					<button type="submit" class="btn btn-primary">SUBMIT</button>
				</div>
		    </div>
		</div>
		</form>
    </div>
</div>
<?php include_once 'footer.php';?>