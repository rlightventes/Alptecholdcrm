<?php
namespace Dompdf;
require_once 'dompdf/autoload.inc.php';
include_once '../common.php';


extract($_GET);
extract($_POST);
 $mysqli->where('service_no', $_GET['service_no']);
    $getCommision = $mysqli->getOne(COMM);
    $mysqli->where('id', $getCommision['client_id']);
	$getUser = $mysqli->getOne(USER);
	
	$getData = $mysqli->getOne(SETT); 

    $m_type = explode(" || ",$machine_type);
    /*print_r($m_type);*/
    $m_name = explode(" || ",$machine_name);
    $m_remark = explode(" || ",$remark);
    
// function fetch_data()  
//  {  
    $output = '';
      $output .= '<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
         <style>
 
    @page { margin: 160px 25px 100px; }
    header { position: fixed; height:120px; top: -130px; left: 0px; right: 0px;  text-align: center; border-bottom:2px solid #000; }
    footer{position:fixed; bottom:0px; text-align:center; border-top:1px solid #000; }
     { page-break-after: always; margin-top:200px;}
    section:last-child { page-break-after: never; }
  </style>
    </head>
    <body>
    <header><img src="assets/img/alp_logo.png" width="200"><h5 style="font-size: 13px;letter-spacing: 1px; margin-top:5px; margin-bottom: 0px;">ALPTECH INTERNATIONAL</h5><h4 style="font-size:12px;margin-top:5px;font-weight: 400;"><b>Address: </b>Plot No. A/232, Road No. 21, ‘Y’ Lane, Wagle Estate,Thane-400 604. INDIA. | <b>Telephone No.:</b> +91 9769976747 / 22-25823203 <br><b>Email.:</b> alptechinternational@gmail.com | <b>Web.:</b> www.alptechindia.com | <b>PAN NO.:</b> AARCA9816A | <b>GST No.: </b> 27AARCA9816A1ZJ</h4></header>
    <footer><h4 style="font-size:12px;margin-top:5px;font-weight: 400;"><b>Sale Office: </b>Office No 9 Gound Floor Sakhi House, Trombay Road, Chembur East, Mumbai - 400071. | <b>Warehouse:</b> Gala No 9, A 6 Block, Padmini Complex Off Kalher Naka, Bhiwandi. | <b>Telephone No.: </b>91 9769976747 | <b>Email: </b> alptechinternational@gmail.com </h4></footer>

        <div class="container" >
            <div class="row">
                <div style="width:50%; float:left; line-height:16px; font-size:12px">';
                if(!empty($getData['com_name'])){
                $output .= '<p><b>'.$getData['com_name'].'</b></p>'; }
	            if(!empty($getData['co_name'])){
	            $output .= '<p><b>'.$getData['co_name'].'</b></p>'; }
	            if(!empty($getData['address'])){
	            $output .= '<b>Address:</b> '.$getData['address'].'</br>'; }
	            if(!empty($getData['tel_no'])){
	            $output .= '<b>Telephone No.:</b> '.$getData['tel_no'].'</br>'; }
	       
                $output .= '</div></div></div></body></html>';  
      
      
    //   echo $output;  
//  } 
 
//  echo fetch_data();
 
$dompdf = new Dompdf(); 
$dompdf->loadHtml($output);

$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("",array("Attachment" => false));
$dompdf->Output('sample.pdf', 'I');  
// We will be outputting a PDF
header('Content-Type: application/pdf');
  
// It will be called downloaded.pdf
header('Content-Disposition: attachment; filename="Expensess_Report_'.$typeName.'_'.date('d-m-Y', time()).'.pdf"');
  
$imagpdf = file_put_contents($image, file_get_contents($file)); 
  
echo $imagepdf;

exit(0);

?>