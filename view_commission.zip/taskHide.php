<?php include 'header.php'?>
            <div class="page-wrapper">
                <?php  $tabName = base64_encode(TASK);?>
                <form method="post" action="ajax.php?action=multiHideTask&loc=taskHide.php&tabName=<?=$tabName?>">
                <div class="content container-fluid">
                    <div class="row">
						
						<div class="col-sm-8">
						    <?php 
						        if(isset($_GET['client'])){
						            	$client = base64_decode($_GET['client']);
							$mysqli->where('id', $client);
							$getUser = $mysqli->getOne(USER);
							$mysqli->where('id', $getUser['assign_to']);
							$getEmp = $mysqli->getOne(UADMIN);
						    ?>
							<h4 class="page-title">Leads  - <?=$getUser['company_name']; ?> <a href="profile.php?client=<?=$_GET['client']?>" class="text-success size15"><i class="fa fa-table"></i></a></h4> 
							<h5><i class="fa fa-user"></i> <?=$getUser['fname'].' '.$getUser['lname']?> | <i class="fa fa-mobile"></i> <?=$getUser['contact1']; ?> |  Assign to: <?=$getEmp['fname']." ".$getEmp['lname']?></h5>
					        <?php }else{?> 
					        	<h4 class="page-title">Tasks</h4>
					        <?php }?>
						</div>
						<div class="col-sm-4 text-right">
						     <button class="btn btn-primary pull-right rounded" type="submit" style="margin-left:10px"><i class="fa fa-eye"></i> Unhide</button>
							<a href="tasks.php" class="btn btn-primary pull-right rounded" ><i class="fa fa-plus"></i> Task</a>
						</div>
					
						<!--<div class="col-sm-1">-->
						<!--	<button class="btn btn-primary rounded pull-right" onclick="myFunction()"><i class="fa fa-list"></i> Filters</button>-->
						<!--</div>-->
						<!--<div class="col-sm-1">-->
						<!--	<a href="export_to_xl.php" class="btn btn-primary rounded pull-right"><i class="fa fa-plus"></i> Export</a>-->
						<!--</div>-->
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
										    <th id="ifd">Select</th>  
											<th id="ifd" width="7%">Task Id</th>
											<th id="ifd">Task Date</th>
											<th id="ifd" width="20%">Task</th>
											<th id="ifd">Company</th>
											<th id="ifd">Assign Team</th>
											<th id="ifd">Start Date</th>
											<th id="ifd">End Date</th>
											<th id="ifd">Created</th>
											<th id="ifd">Priority</th>
											<th id="ifd">Status</th>
											<th class="text-right">Action</th>
										</tr>
									</thead>
									<tbody>
									  <?php 
									   if(isset($_GET['client'])){
									   $mysqli->where('client', $client);
									   }
									  $mysqli->orderBy('id', 'desc');
									  $mysqli->groupBy('task');
									  $allTask = $mysqli->get(TASK);
									  foreach($allTask as $taskVal){
									      $task = base64_encode($taskVal['task_id']);
									      $mysqli->where('id', $taskVal['client']);
									      $getClient = $mysqli->getOne(USER);
									    if($taskVal['complete_task'] == '1'){
									      $statusName = 'Working';
									  }elseif($taskVal['complete_task'] == '2'){
									      $statusName = 'Complete';
									  }elseif($taskVal['complete_task'] == '3'){
									      $statusName = 'Pending';
									  }elseif($taskVal['complete_task'] == '4'){
									      $statusName = 'Overdue';
									  }else{
									       $statusName = 'New';
									  }
									  	$lead = base64_encode($getClient['id']);
									  	if($taskVal['hide'] == '1'){
									  ?>  
									    <tr>
									        <td style="vertical-align:top"><input type="checkbox" name="lead[]" value="<?=$taskVal['task_id']?>" class="addProduct"/></td>
									        <td style="vertical-align:top"><a href="task_view.php?task=<?=$task?>">TSK-<?=$taskVal['task_id']?></a></td>
									        <td style="vertical-align:top"><?=date('d/m/Y', strtotime($taskVal['created_date']))?></td>
									        <td style="vertical-align:top"><?=$taskVal['task']?></td>
									        <td style="vertical-align:top"><?=$getClient['company_name']?></td>
									       <td style="text-transform:capitalize">
									     <?php 
									     $mysqli->groupBy('employee_list');
									     $mysqli->where('task_id', $taskVal['task_id']);
									     $empName = $mysqli->get(TASK);
									     foreach($empName as $nameEmp){
									      if(!empty($nameEmp['employee_list'])):
								        $mysqli->where('id', $nameEmp['employee_list']);
							            $nameUser = $mysqli->getOne(UADMIN);
									        echo "<p>&bull; ".$nameUser['fname']." ".$nameUser['lname']."</p>";
									     endif;
									         
									     }
									     
									     
									     ?>
									        </td>
									        <td style="vertical-align:top"><?=$taskVal['start_date']?></td>
									        <td style="vertical-align:top"><?=$taskVal['end_date']?></td>
									        <td style="vertical-align:top">
									             <?php 
								$mysqli->where('id', $taskVal['createTask']);
							    $createUser = $mysqli->getOne(UADMIN); 
							    echo $createUser['fname']." ".$createUser['lname'];
									       ?>   </td>
									        <td style="vertical-align:top"><?=$taskVal['priority']?></td>
									        <td style="vertical-align:top"><?=$statusName?></td>
									        <td class="text-right" style="vertical-align:top">

												<div class="dropdown">
													<a href="profile.php?client=<?=$lead?>" class="text-success size15"><i class="fa fa-th m-r-5"></i> </a>
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
                                                    <ul class="dropdown-menu pull-right">
														<li><a href="ajax.php?action=unhideTask&lead=<?=$task?>&tabName=<?=$tabName?>&loc=taskHide.php"><i class="fa fa-eye m-r-5"></i> Unhide</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_task" data-id="<?=$taskVal['task_id']?>" class="delete"><i class="fa fa-trash-o m-r-5"></i> Permanent Delete</a></li>
													</ul>
												</div>
											</td>
									    </tr>
									    <?php } } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
                </form>
				<?php include 'messages.php'?>
            </div>
			<div id="delete_task" class="modal custom-modal fade" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content modal-md">
							<div class="modal-header">
								<h4 class="modal-title">Delete Permanently Task</h4>
							</div>
							<form method="post" action="ajax.php?action=deletePermanat">
								<input type="hidden" name="id" value="" id="del_id" >
								<input type="hidden" name="tab_name" value="<?=TASK?>" >
								<input type="hidden" name="col_nam" value="task_id" >
								<input type="hidden" name="loc" value="taskHide.php" >
								<div class="modal-body card-box">
									<p>Are you sure want to Permanently delete this?</p>
									<div class="m-t-20"> <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
										<button type="submit" class="btn btn-danger">Delete</button>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
        </div>
        <script type="text/javascript">
   $('#genderType').hide();
    $('#dateView').hide();
  $('#product_typeType').hide();
  $('#stageID').hide();
  $('#brandType').hide();
  $('#priorityType').hide();
  $("#search_from").change(function(){
  var selectVal = $(this).val();
  //alert(selectVal);


if(selectVal == 'id' || selectVal == 'name' || selectVal == 'leader' || selectVal == 'status' || selectVal == 'team' || selectVal == 'priority'){
  $('#type').html("<select class='form-control' name='search_type'><option value='='>Equal</option></select>");
}
else if( selectVal == 'deadline' ){
   $('#type').html("<select class='form-control' name='search_type'><option value='>='>Min </option><option value='<='>Max</option></select>");
}
if(selectVal == 'id' || selectVal == 'name' || selectVal == 'team' || selectVal == 'purchase_rate' || selectVal == 'leader'){
  $('#canId').html('<input class="form-control" type="text" name="search_value">');
}
else if(selectVal == 'deadline'){
    $('#canId').html('<input class="form-control datetimepicker" type="date"  name="search_value" >');
}
else if(selectVal == 'status'){
    $('#canId').html("<select class='form-control' name='search_value' ><option>Select Status</option><option value='Active'>Active</option><option value='Inactive'>Inactive</option></select>");
}
else if(selectVal == 'priority'){
    $("#canId").html("<select class='form-control' name='search_value' id='priorityType'><option>Select Priority</option><option value='high'><i class='fa fa-dot-circle-o text-danger'></i>High</option><option value='medium'>Medium</option><option value='low'>Low</option></select>"); 
}
  });
</script>
<?php include 'footer.php'?>
<script type="text/javascript">
			$('.delete').click(function(){
				var id = $(this).attr('data-id');
				$('#del_id').val(id);
				//alert(id);
			})
		</script>