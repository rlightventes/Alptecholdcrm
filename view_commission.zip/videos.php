<?php include 'header.php'?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-sm-4">
							<h4 class="page-title">Videos</h4>
						</div>
						<div class="col-sm-7 text-right m-b-20">
							<a href="add-videos.php" class="btn btn-primary rounded pull-right"><i class="fa fa-plus"></i> Create Videos</a>
						</div>
						<div class="col-sm-1">
							<button class="btn btn-primary rounded pull-right" onclick="myFunction()"><i class="fa fa-list"></i> Filters</button>
						</div>
					</div>
					<div id="filter">
                    	<form action="" method="post">
                			<table class="table table-striped">
                				<tr >
                    				<td colspan="" width="20%">
                      					<select class="form-control" name="search_from" id="search_from" >
                        					<option value="Search for">Search for</option>
                        					<option value="id">Product Id</option>
                        					<option value="name">Product Name</option>
                        					<option value="product_type">Product Type</option>
                        					<option value="brand">Brand</option>
                        					<option value="purchase_rate">Purchase Rate</option>
                        					<option value="price">Price</option>
                        					<option value="deadline">Deadline</option>
                        					<option value="priority">Priority</option>
                        					<option value="status">Status</option>
                      					</select>
                    				</td>
                    				<td colspan="2" width="15%">
                      					<select class="form-control" name="search_type" id="type" style="display: block;">
                        					<option>Select Search Type</option>
                        					<option value="LIKE">Start with</option>
                        					<option value="LIKE">End with</option>
                        					<option value=">=">Min</option>
                        					<option value="<=">Max</option>
                        					<option value="=">Equal</option>
                      					</select>
                      					<p id="msg"></p>
                    				</td>
                    				<td width="30%">
                    					<div id="canId">
                    						<input class="form-control" type="text" name="search_value">
                    					</div>
                    				</td>
                    				<td width="10%" style="border: none; text-align: center;" >
                    					<div>                   						
                    					<input type="submit" class="btn btn-success btn-block" name="rangetwo" value="SEARCH">
                    					</div>
                    				</td>
                    			</tr>
                    			<tr>
                    			</tr>
                    		</table>
                    	</form>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="table-responsive">
								<table class="table table-striped custom-table" id="example" style="width:100%">
									<thead>
										<tr>
											<th>Sr No</th>
											<th id="ifd">Product</th>
											
											
											<!-- <th >Status</th>-->
											<th class="text-right">Action</th> 
										</tr>
									</thead>
									<tbody>
									<?php 
									
									$mysqli->orderBy('id', 'desc');
									$getProduct = $mysqli->get(VIDEO);
									foreach ($getProduct as $prVal) {
										extract($prVal);
										
											$text = ($status == '1')? 'Active' : 'Inactive';
											$bg = ($status == '1')? 'success' : 'danger';
											$val = ($status == '1')? '0' : '1';
											if($status != '2'):

												
												$loc = 'videos.php';
												$tabName = VIDEO;
												$videos = base64_encode($id);
												
									?>

										<tr>
											<td><?=$id?></td>
											<td>
												<h2><a data-toggle="modal" data-target="#myModal_<?=$id?>"><?=$name?></a></h2>
												<!-- Modal -->
												<div id="myModal_<?=$id?>" class="modal fade" role="dialog" style="margin-top: 50px">
												  <div class="modal-dialog">

												    <!-- Modal content-->
												    <div class="modal-content">
												      <div class="modal-header">
												        <button type="button" class="close" data-dismiss="modal">&times;</button>
												        <h4 class="modal-title"><?=$name?></h4>
												      </div>
												      <div class="modal-body">
												        <iframe width="100%" height="400" src="<?=$youtub_link?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
												      </div>
												      
												    </div>

												  </div>
												</div>

											</td>
											
											
											<td class="text-right">
												<div class="dropdown">
													<a href="#" class="action-icon dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-ellipsis-v"></i></a>
													<ul class="dropdown-menu pull-right">
														<li><a href="add-videos.php?product=<?=$videos?>"><i class="fa fa-pencil m-r-5"></i> Edit</a></li>
														<li><a href="#" data-toggle="modal" data-target="#delete_project" class="delete" data-id="<?=$id?>"><i class="fa fa-trash-o m-r-5" ></i> Delete</a></li>
													</ul>
												</div>
											</td>
										</tr> 
										<?php endif; } ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
                </div>
				<?php include 'messages.php'?>
            </div>			
			<div id="delete_project" class="modal custom-modal fade" role="dialog">
				<div class="modal-dialog">
					<div class="modal-content modal-md">
						<div class="modal-header">
							<h4 class="modal-title">Delete Video</h4>
						</div>
						<form method="post" action="ajax.php?action=delete">
								<input type="hidden" name="id" value="" id="del_id" >
								<input type="hidden" name="tab_name" value="<?=VIDEO?>" >
								<input type="hidden" name="col_nam" value="id" >
								<input type="hidden" name="loc" value="videos.php" >
						<div class="modal-body card-box">
							<p>Are you sure want to delete this?</p>
							<div class="m-t-20"> <a href="#" class="btn btn-default" data-dismiss="modal">Close</a>
								<button type="submit" class="btn btn-danger">Delete</button>
							</div>
						</div>
						</form>	
					</div>
				</div>
			</div>
        </div>
        <script type="text/javascript">
			$('.delete').click(function(){
				var id = $(this).attr('data-id');
				$('#del_id').val(id);
		//	alert(id);
			})
		</script>
       
<?php include 'footer.php'?>
