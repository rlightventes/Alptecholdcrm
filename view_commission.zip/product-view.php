<?php include'header.php'?>
<?php 
	$id = base64_decode($_GET['product']);
	$mysqli->where('id', $id);
	$getProduct = $mysqli->getOne(PRODUCT);
	extract($getProduct);
	if($country == 'Italian'):
		$img = '../img/italian.jpg';
	elseif($country == 'Turkish'):
		$img = '../img/turkish.jpg';
	elseif($country == 'Korean'):
		$img = '../img/koren.jpg';
	elseif($country == 'India'):
		$img = '../img/india.jpg';
	endif;
	$pic1 = (!empty($img1))? '../Images/'.$img1 : 'assets/img/placeholder.png';
	$pic2 = (!empty($img2))? '../Images/'.$img2 : 'assets/img/placeholder.png';
	$pic3 = (!empty($img3))? '../Images/'.$img3 : 'assets/img/placeholder.png';
	$pic4 = (!empty($img4))? '../Images/'.$img4 : 'assets/img/placeholder.png';
	$mysqli->where('id', $category);
// 	$mysqli->where('category', 'category');
	$getMain = $mysqli->getOne(MAINCAT);
	$mysqli->where('id', $type);
//	$mysqli->where('category', 'subcategory');
	$getSub = $mysqli->getOne(MAINCAT);

?>
            <div class="page-wrapper">
                <div class="content container-fluid">
					<div class="row">
						<div class="col-xs-8">
							<h4 class="page-title"><?=$name?></h4>
						</div>
						<div class="col-sm-4 text-right m-b-30">
							<a href="add-products.php?product=<?=$_GET['product']?>" class="btn btn-primary rounded"><i class="fa fa-plus"></i> Edit Product</a>
							<a href="convert_pdf.php?product=<?=$_GET['product']?>" target="_blank" class="btn btn-primary rounded"><i class="fa fa-file-pdf-o"></i> PDF Genrate</a>
						</div>
					</div>
					<div class="row">

						<?php $col = ($getAdmin['profile_type'] == 'Admin')? '9': '12';?>
						<div class="col-lg-<?=$col?>">
							<div class="panel">
								<div class="panel-body">
								    <div class="col-lg-4">
								        <img src="<?=$pic1?>" class="img-responsive" alt="">   
								    </div>
								    <div class="col-lg-8">
								        <div class="project-title">
    										<h5 class="panel-title"><?=$name?></h5>
    										<small><?=$getMain['category_name']?> &rarr; <?=$getSub['category_name']?></small>
    										<hr/>
									    </div>
									    <?=$description?> 
    									<?php if(!empty($specification)): ?>
    									<br/><br/>
    									<h5><strong>SPECIFICATION:</strong></h5>
    									<?=$specification?> 
    									<?php endif;?>
								    </div>
								</div>
							</div>
							<div class="panel">
								<div class="panel-body">
				                    <h5 class="panel-title m-b-20">Uploaded image files</h5>
									<div class="row">
										<div class="col-md-4 col-sm-6">
											<div class="thumbnail">
												<div class="thumb">
													<img src="<?=$pic2?>" class="img-responsive" alt="">
												</div>
												<!-- <div class="caption text-center">
													 demo.png
												</div> -->
											</div>
										</div>
										<div class="col-md-4 col-sm-6">
											<div class="thumbnail">
												<div class="thumb">
													<img src="<?=$pic3?>" class="img-responsive" alt="">
												</div>
												<!-- <div class="caption text-center">
													 demo.png
												</div> -->
											</div>
										</div>
										<div class="col-md-4 col-sm-6">
											<div class="thumbnail">
												<div class="thumb">
													<img src="<?=$pic4?>" class="img-responsive" alt="" >
												</div>
												<!-- <div class="caption text-center">
													 demo.png
												</div> -->
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="panel">
								<div class="panel-body">
									<h5 class="panel-title m-b-20">Uploaded files</h5>
									<ul class="files-list">
										<?php if(!empty($pdf1)): ?>
										<li>
											<div class="files-cont">
												<div class="file-type">
													<span class="files-icon"><i class="fa fa-file-pdf-o"></i></span>
												</div>
												<div class="files-info">
													<span class="file-name"><a href="../PDFs/<?=$pdf1?>" download target="_blank">Download</a></span>
													<br/><br/>
													
												</div>
											</div>
										</li>
										<?php endif; ?>
										<?php if(!empty($pdf2)): ?>
										<li>
											<div class="files-cont">
												<div class="file-type">
													<span class="files-icon"><i class="fa fa-file-pdf-o"></i></span>
												</div>
												<div class="files-info">
													<span class="file-name"><a href="../PDFs/<?=$pdf2?>" target="_blank">Download</a></span>
													 <br/><br/>
													
												</div>
											</div>
										</li>
										<?php endif; ?>
										<?php if(!empty($pdf3)): ?>
										<li>
											<div class="files-cont">
												<div class="file-type">
													<span class="files-icon"><i class="fa fa-file-pdf-o"></i></span>
												</div>
												<div class="files-info">
													<span class="file-name"><a href="../PDFs/<?=$pdf3?>" target="_blank">Download</a></span>
													<br/><br/>
													
												</div>
											</div>
										</li>
										<?php endif; ?>
									</ul>
								</div>
							</div>
							<div class="panel">
								<div class="panel-body">
									<h5 class="panel-title m-b-20">Video</h5>
									<ul class="files-list">
										<?php if(!empty($youtube)): 
											$explode = explode("embed/", $youtube);
											?>
										<li>
											<iframe width="100%" height="450"
src="https://www.youtube.com/embed/<?=$explode['1']?>" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen>
</iframe>
										</li>
										<?php endif; ?>
										
									</ul>
								</div>
							</div>
							<div class="panel">
								<div class="panel-body">
									<h5 class="panel-title m-b-20">After Sale Videos</h5>
									<ul class="files-list">
										<?php 
										    $mysqli->where('prod_id', $id);
										    $getAfterSale = $mysqli->get(ASALES);
										if(count($getAfterSale) != 0): 
										    foreach($getAfterSale as $sale){
										        extract($sale);
										        if($hide != 1){
											$explode = explode("embed/", $link);
											?>
										<li>
										    <h5><?=$name?></h5>
										    <div><?=$details?></div>
										    <p><a href="<?=$link?>" target="_blank"><?=$link?></a></p>
<!--											<iframe width="100%" height="450"-->
<!--src="https://www.youtube.com/embed/<?=$explode['1']?>">-->
<!--</iframe>-->
										</li>
										<?php } } endif; ?>
										
									</ul>
								</div>
							</div>
						</div>
						<?php if($getAdmin['profile_type'] == 'Admin'):?>
						<div class="col-lg-3">
							<div class="panel">
								<div class="panel-body">
									<h6 class="panel-title m-b-15">Product Details</h6>
									<table class="table table-striped table-border">
										<tbody>
											<tr>
												<td>Product Code:</td>
												<td class="text-right">PRO-<?=$id?></td>
											</tr>
											<tr>
												<td>Country:</td>
												<td class="text-right"><img src="<?=$img?>" width="30"/> <?=$country?></td>
											</tr>
											<tr>
												<td>List Price:</td>
												<td class="text-right"><i class="fa fa-rupee"></i> <?=$mrp?>/-</td>
											</tr>
											<tr>
												<td>Sale Price:</td>
												<td class="text-right"><i class="fa fa-rupee"></i> <?=$sale_rate?>/-</td>
											</tr>
											<tr>
												<td>HSN Code:</td>
												<td class="text-right"><?=$hsn_code?></td>
											</tr>
											<tr>
												<td>Unit:</td>
												<td class="text-right"><?=$unit?></td>
											</tr>
											<tr>
												<td>Gross Weight:</td>
												<td class="text-right"> <?=$gross_weight?></td>
											</tr>
											<tr>
												<td>Net Weight:</td>
												<td class="text-right"> <?=$net_weight?></td>
											</tr>
											
											<!--<tr>-->
											<!--	<td>Weight:</td>-->
											<!--	<td class="text-right"> <?=$product_weight?></td>-->
											<!--</tr>-->
											<tr>
												<td>Dimension:</td>
												<td class="text-right"> <?=$product_dimension?></td>
											</tr>
											
											

											
										</tbody>
									</table>
									
								</div>
							</div>
							<!-- <div class="panel project-user">
								<div class="panel-body">
									<h6 class="panel-title m-b-20">Assigned Leader <a class="pull-right btn btn-primary btn-xs" data-toggle="modal" data-target="#assign_leader"><i class="fa fa-plus"></i> Add</a></h6>
									<ul class="list-box">
										<li>
											<a href="profile.php">
												<div class="list-item">
													<div class="list-left">
														<span class="avatar">W</span>
													</div>
													<div class="list-body">
														<span class="message-author">Wilmer Deluna</span>
														<div class="clearfix"></div>
														<span class="message-content">Team Leader</span>
													</div>
												</div>
											</a>
										</li>
										<li>
											<a href="profile.php">
												<div class="list-item">
													<div class="list-left">
														<span class="avatar">L</span>
													</div>
													<div class="list-body">
														<span class="message-author">Lesley Grauer</span>
														<div class="clearfix"></div>
														<span class="message-content">Team Leader</span>
													</div>
												</div>
											</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="panel project-user">
								<div class="panel-heading">
									<h6 class="panel-title">Assigned users <a class="pull-right btn btn-primary btn-xs" data-toggle="modal" data-target="#assign_user"><i class="fa fa-plus"></i> Add</a></h6>
								</div>
								<div class="panel-body">
									<ul class="list-box">
										<li>
											<a href="profile.php">
												<div class="list-item">
													<div class="list-left">
														<span class="avatar">J</span>
													</div>
													<div class="list-body">
														<span class="message-author">John Doe</span>
														<div class="clearfix"></div>
														<span class="message-content">Web Designer</span>
													</div>
												</div>
											</a>
										</li>
										<li>
											<a href="profile.php">
												<div class="list-item">
													<div class="list-left">
														<span class="avatar">V</span>
													</div>
													<div class="list-body">
														<span class="message-author">Richard Miles</span>
														<div class="clearfix"></div>
														<span class="message-content">Web Developer</span>
													</div>
												</div>
											</a>
										</li>
									</ul>
								</div>
							</div> -->
						</div>
					<?php endif;?>
					</div>
                </div>
				<?php include 'messages.php';?>
            </div>
			
        </div>
        
    <?php include'footer.php';?>