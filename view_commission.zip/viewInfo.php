<?php include_once 'header.php'; ?>


<!-- Stylesheet file -->
<link rel="stylesheet" href="style.css">

<!-- jQuery library -->
<script src="jquery.min.js"></script>

<div class="page-wrapper">
	<div class="content container-fluid">
		<div class="row">
			<div class="col-md-12" >
				<div class="col-md-12" style="background: #fff; padding: 20px">
				    <?php 
				        $userRe = $_GET['user'];
				        $currDate = $_GET['currnt'];
				        $mysqli->where('id', $userRe);
			            $reportUesr = $mysqli->getOne(UADMIN);
			            	$mysqli->where('user_id', $userRe);
							$mysqli->where('date', $currDate);
							$userAtt = $mysqli->getOne(ATTN);
							 $time1 = new DateTime($userAtt['in_time']);
					//	echo date('H:i:s', strtotime($userAtt['out_time']));
$time2 = new DateTime($userAtt['out_time']);
$timediff = $time1->diff($time2);
$working = $timediff->format('%h : %i');
				    ?>
				    <h4><b><?=$reportUesr['fname'].' '.$reportUesr['lname']?></b> | <?=$currDate?></h4>
				    
		            <p style="color:#666; font-weight:normal" class="col-md-4 col-xs-4  col-sm-4"><b>In Time: <?php if(!empty($userAtt['in_time'])){ echo date('h:i a', strtotime($userAtt['in_time'])); } ?></b><br/> <?=$userAtt['in_address']?></p>
                    <p style="color:#666; font-weight:normal" class="col-md-4 col-xs-4  col-sm-4"><b>Out Time: <?php if(!empty($userAtt['out_time'])){ echo date('h:i a', strtotime($userAtt['out_time'])); } ?></b><br/> <?=$userAtt['out_address']?></p>
                    <p style="color:#666; font-weight:normal" class="col-md-4 col-xs-4  col-sm-4"><b>Working Hours: <?php if(!empty($userAtt['in_time'])){ echo $working; } ?></b></p>

				    <hr />
				    <div style="clear:both"></div>
                    <?php 
                    $mysqli->where('quotation_date', $currDate);
                    $mysqli->where('emp_id', $userRe);
                    $mysqli->groupBy('quot_id');
                    $totalQt = $mysqli->get(QOT);
                    ?>
				    <div class="col-md-2 col-xs-12  col-sm-12 panel panel-body label-success text-center " style="color:#fff">
				      <a href="?user=<?=$_GET['user']?>&currnt=<?=$_GET['currnt']?>&tab=qot" style="color:#fff">      
				       <h1 style="color:#fff"><?=count($totalQt)?></h1> 
				       <p>TOTAL QUOTE</p>
				        </a>  
				    </div>
				    <div class="col-md-2 col-xs-12  col-sm-12 panel panel-body label-warning text-center " style="color:#fff">
				       <h1 style="color:#fff">0</h1> 
				       <p>TOTAL INVOICE</p>
				    </div> 
				    <?php 
				    $totalGenral = '0';
				    $mysqli->where('history_type', 'General');
			        $mysqli->where('emp_id', $userRe);
		        	$getGeneral = $mysqli->get(HISTORY);
		        	foreach($getGeneral as $genRal){
		        	    $dateGen = date('Y-m-d', strtotime($genRal['create_date']));
		        	    if($currDate == $dateGen){
		        	        $totalGenral++;
		        	    }
		        	}
				    ?>
				    
				     <a href="?user=<?=$_GET['user']?>&currnt=<?=$_GET['currnt']?>&tab=general" class="col-md-2 col-xs-12  col-sm-12  panel panel-body label-danger text-center " style="color:#fff">
				       <h1 style="color:#fff"><?=$totalGenral?></h1> 
				       <p>TOTAL GENERAL</p>
				    </a>
				    <?php 
				    $totalMeet = '0';
				    $mysqli->where('history_type', 'Meeting');
			        $mysqli->where('emp_id', $userRe);
		        	$getGeneral = $mysqli->get(HISTORY);
		        	foreach($getGeneral as $genRal){
		        	    $dateGen = date('Y-m-d', strtotime($genRal['create_date']));
		        	    if($currDate == $dateGen){
		        	        $totalMeet++;
		        	    }
		        	}
				    ?>
				    <a href="?user=<?=$_GET['user']?>&currnt=<?=$_GET['currnt']?>&tab=meet" class="col-md-2 col-xs-12  col-sm-12  panel panel-body label-info text-center " style="color:#fff">
				       <h1 style="color:#fff"><?=$totalMeet?></h1> 
				       <p>TOTAL MEETING</p>
				    </a>
				     <?php 
				    $totalCall = '0';
				    $mysqli->where('history_type', 'Call');
			        $mysqli->where('emp_id', $userRe);
		        	$getGeneral = $mysqli->get(HISTORY);
		        	foreach($getGeneral as $genRal){
		        	    $dateGen = date('Y-m-d', strtotime($genRal['create_date']));
		        	    if($currDate == $dateGen){
		        	        $totalCall++;
		        	    }
		        	}
				    ?>
				    <a href="?user=<?=$_GET['user']?>&currnt=<?=$_GET['currnt']?>&tab=call" class="col-md-2 col-xs-12  col-sm-12  panel panel-body label-primary text-center " style="color:#fff">
				       <h1 style="color:#fff"><?=$totalCall?></h1> 
				       <p>TOTAL CALL</p>
				    </a>
				    <?php 
				    $totalTask = '0';
				    $mysqli->where('history_type', 'Task');
			        $mysqli->where('emp_id', $userRe);
		        	$getGeneral = $mysqli->get(HISTORY);
		        	foreach($getGeneral as $genRal){
		        	    $dateGen = date('Y-m-d', strtotime($genRal['create_date']));
		        	    if($currDate == $dateGen){
		        	        $totalTask++;
		        	    }
		        	}
				    ?>
				    <a href="?user=<?=$_GET['user']?>&currnt=<?=$_GET['currnt']?>&tab=task" class="col-md-2 col-xs-12 col-sm-12 panel panel-body label-success text-center " style="color:#fff">
				       <h1 style="color:#fff"><?=$totalTask?></h1> 
				       <p>TOTAL TASK</p>
				    </a>
				    
				    <?php 
				        if(isset($_GET['tab'])){
				            switch($_GET['tab']){
				                case'qot': ?>
				                  	<table class="table table-striped custom-table m-b-0" id="example">
									<thead>
										<tr>
											<th>#</th>
											<th id="ifd"># QT No </th>
											<th id="ifd">Client Name</th>
											<th id="ifd">Subject </th>
											<th id="ifd">PDF</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										$sr = '1';
										
										if($getAdmin['profile_type'] != 'Admin'):
										$mysqli->where('assign', $getAdmin['id']);
										endif;
										$mysqli->orderBy('id','asc');
										$mysqli->where('quotation_date', $currDate);
                                        $mysqli->where('emp_id', $userRe);
										$mysqli->groupBy('quot_id');
										$getLeads = $mysqli->get(QOT);
										foreach ($getLeads as $leadsVal) {
											extract($leadsVal);
										$client = base64_decode($client_id);
											$mysqli->where('id', $client_id);
											$getUser = $mysqli->getOne(USER);
											$client = base64_encode($getUser['id']);
											$mysqli->where('id', $product_id);
											$getProduct = $mysqli->getOne(PRODUCT);
											$product = base64_encode($product_id);
											 $date1 = strtotime($created_date);  
											 $date2 = time();
											 $diff = abs($date2 - $date1);  
											 $years = floor($diff / (365*60*60*24));  
											 $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));
											 $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24)); 
											 $hours = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24) / (60*60)); 
											 $minutes = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24  
                          - $hours*60*60)/ 60);  
											 $seconds = floor(($diff - $years * 365*60*60*24  - $months*30*60*60*24 - $days*60*60*24 
                - $hours*60*60 - $minutes*60));  

											 if($days != '0'):
											 	$create = $days.' Days ago';
											 else:
											 	if($hours != '0'):
											 		$create = $hours.' hrs ago';
											 	else:
											 		$create = $minutes.' min ago';
											 	endif;

											 endif;
											 $lead = base64_encode($id);
										?>
									
										
										<tr>
											<td><?=$sr++?></td>
											<td><a href="qtView.php?lead=<?=$lead?>" target="_blank"><?=$quot_id?></a></td>
											<td><?=$getUser['company_name']?></td>
											<td><?=$subject?></td>
											<td>
											     <?php  if($qotPDF == '1'){?>
										         <a href="pdf/<?=$qtID?>.pdf" download="" class="label label-success">Download</a>   
										          <?php  }else{?>
										          <a href="convert_qot.php?qtID=<?=$lead?>" class="label label-danger" target="_blank">Generate</a>  
										           <?php  }
										        ?></td>
											<!--<td></td>-->
											<!--<td></td>-->
											<!--<td></td>-->
											<td><a href="profile.php?client=<?=$client?>" class="text-success size15"><i class="fa fa-table"></i></a></td>
											
										
										</tr>
										<?php }?>
										
									</tbody>
								</table>  
				                    
				                    
				              <?php  break;
				                case'general':?>
				                		<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
											<th id="ifd">End Date</th>
											<th id="ifd">Type</th>
											<th id="ifd">Updated By</th>
											<th id="ifd">Agenda</th>
											<th id="ifd">To Client</th>
											<th class="text-center" id="ifd">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										
										$mysqli->where('history_type', 'General');
			                            $mysqli->where('emp_id', $userRe);
										$getTask = $mysqli->get(HISTORY);
										foreach ($getTask as $taskVal) {
										     $dateGen = date('Y-m-d', strtotime($taskVal['create_date']));
		        	                        if($currDate == $dateGen){
											$mysqli->where('id', $taskVal['emp_id']);
											$getUserEm = $mysqli->getOne(UADMIN);
											if($getUserEm['id'] == $getAdmin['id']):
												$taskName = 'Self';
											else:
												$taskName = $getUserEm['fname'].' '.$getUserEm['lname'];
											endif;
											$mysqli->where('id', $taskVal['task_id']);
											$taskName = $mysqli->getOne(TASK);
										    $client = base64_encode($taskVal['client_id']);
										    
											$mysqli->where('id', $taskVal['client_id']);
											$getClient = $mysqli->getOne(USER);
										?>
										<tr>
											
											<td><?=$taskVal['reminder']?></td>
											<td><?=$taskVal['history_type']?></td>
											<td><?=$getUserEm['fname'].' '.$getUserEm['lname']?></td>
											<td><?=$taskVal['subject']?></td>
											<td><?=$getClient['company_name']?></td>
											<td class="text-center"><a href="profile.php?client=<?=$client?>" class="text-success size15"><i class="fa fa-table"></i></a>
												<!-- Modal -->
											</td>
											
										</tr>
										<?php }} ?>	
									</tbody>
								</table>
				             <?php   break;
				             
				                case'call':?>
				                		<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
											<th id="ifd">End Date</th>
											<th id="ifd">Type</th>
											<th id="ifd">Updated By</th>
											<th id="ifd">Agenda</th>
											<th id="ifd">To Client</th>
											<th class="text-center" id="ifd">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										
										$mysqli->where('history_type', 'Call');
			                            $mysqli->where('emp_id', $userRe);
										$getTask = $mysqli->get(HISTORY);
										foreach ($getTask as $taskVal) {
										     $dateGen = date('Y-m-d', strtotime($taskVal['create_date']));
		        	                        if($currDate == $dateGen){
											$mysqli->where('id', $taskVal['emp_id']);
											$getUserEm = $mysqli->getOne(UADMIN);
											if($getUserEm['id'] == $getAdmin['id']):
												$taskName = 'Self';
											else:
												$taskName = $getUserEm['fname'].' '.$getUserEm['lname'];
											endif;
											$mysqli->where('id', $taskVal['task_id']);
											$taskName = $mysqli->getOne(TASK);
												$client = base64_encode($taskVal['client_id']);
										
										$mysqli->where('id', $taskVal['client_id']);
											$getClient = $mysqli->getOne(USER);
										?>
										<tr>
											
											<td><?=$taskVal['reminder']?></td>
											<td><?=$taskVal['history_type']?></td>
											<td><?=$getUserEm['fname'].' '.$getUserEm['lname']?></td>
											<td><?=$taskVal['subject']?></td>
											<td><?=$getClient['company_name']?></td>
											<td class="text-center"><a href="profile.php?client=<?=$client?>" class="text-success size15"><i class="fa fa-table"></i></a>
												<!-- Modal -->
											</td>
											
										</tr>
										<?php }} ?>	
									</tbody>
								</table>
				             <?php   break;
				             case'meet':?>
				                		<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
											<th id="ifd">End Date</th>
											<th id="ifd">Type</th>
											<th id="ifd">Updated By</th>
											<th id="ifd">Agenda</th>
											<th id="ifd">To Client</th>
											<th class="text-center" id="ifd">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										
										$mysqli->where('history_type', 'Meeting');
			                            $mysqli->where('emp_id', $userRe);
										$getTask = $mysqli->get(HISTORY);
										foreach ($getTask as $taskVal) {
										     $dateGen = date('Y-m-d', strtotime($taskVal['create_date']));
		        	                        if($currDate == $dateGen){
											$mysqli->where('id', $taskVal['emp_id']);
											$getUserEm = $mysqli->getOne(UADMIN);
											if($getUserEm['id'] == $getAdmin['id']):
												$taskName = 'Self';
											else:
												$taskName = $getUserEm['fname'].' '.$getUserEm['lname'];
											endif;
											$mysqli->where('id', $taskVal['task_id']);
											$taskName = $mysqli->getOne(TASK);
												$client = base64_encode($taskVal['client_id']);
										$mysqli->where('id', $taskVal['client_id']);
											$getClient = $mysqli->getOne(USER);
										?>
										<tr>
											
											<td><?=$taskVal['reminder']?></td>
											<td><?=$taskVal['history_type']?></td>
											<td><?=$getUserEm['fname'].' '.$getUserEm['lname']?></td>
											<td><?=$taskVal['subject']?></td>
											<td><?=$getClient['company_name']?></td>
											<td class="text-center"><a href="profile.php?client=<?=$client?>" class="text-success size15"><i class="fa fa-table"></i></a>
												<!-- Modal -->
											</td>
											
										</tr>
										<?php }} ?>	
									</tbody>
								</table>
				             <?php   break;
				             case'task':?>
				                		<table class="table table-striped custom-table" id="example">
									<thead>
										<tr>
											<th id="ifd">End Date</th>
											<th id="ifd">Type</th>
											<th id="ifd">Updated By</th>
											<th id="ifd">Task Name</th>
											<th id="ifd">To Client</th>
											<th class="text-center" id="ifd">Action</th>
										</tr>
									</thead>
									<tbody>
										<?php 
										
										$mysqli->where('history_type', 'Task');
			                            $mysqli->where('emp_id', $userRe);
										$getTask = $mysqli->get(HISTORY);
										foreach ($getTask as $taskVal) {
										     $dateGen = date('Y-m-d', strtotime($taskVal['create_date']));
		        	                        if($currDate == $dateGen){
											$mysqli->where('id', $taskVal['emp_id']);
											$getUserEm = $mysqli->getOne(UADMIN);
											if($getUserEm['id'] == $getAdmin['id']):
												$taskName = 'Self';
											else:
												$taskName = $getUserEm['fname'].' '.$getUserEm['lname'];
											endif;
											$mysqli->where('id', $taskVal['task_id']);
											$taskName = $mysqli->getOne(TASK);
											$client = base64_encode($taskVal['client_id']);
											$mysqli->where('id', $taskVal['client_id']);
											$getClient = $mysqli->getOne(USER);
										?>
										<tr>
											
											<td><?=$taskVal['reminder']?></td>
											<td><?=$taskVal['history_type']?></td>
											<td><?=$getUserEm['fname'].' '.$getUserEm['lname']?></td>
											<td><?=$taskVal['subject']?></td>
											<td><?=$getClient['company_name']?></td>
											<td class="text-center"><a href="profile.php?client=<?=$client?>" class="text-success size15"><i class="fa fa-table"></i></a>
												<!-- Modal -->
											</td>
											
										</tr><?php }} ?>	
									</tbody>
								</table>
				             <?php   break;
				            }
				        }
				    ?>
				       
          
        
      			<div>
			</div>		
		</div>
	</div>
</div>
<?php include_once "footer.php"; ?>
 