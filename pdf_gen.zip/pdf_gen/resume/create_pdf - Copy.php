<?php include '../common/common.php';?>
<?php
  $mysqli->where('id', $_GET['in']);
  $invoice = $mysqli->getOne(QUOT);
  /*echo $invoice['product_id'];
  echo $invoice['qtys'];
  echo $invoice['vendor_id'];*/
  /*print_r(explode(" ",$invoice['product_id']));*/
  $str_arr = preg_split ("/\,/", $invoice['product_id']);
  /*print_r($str_arr);*/
  $p_id=explode(" ",$invoice['product_id']);
  /*print_r($p_id);*/
  $qtys=explode(",",$invoice['product_qty']);
  /*print_r($qtys);*/
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Bootstrap Css -->
    <link href="../assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />        
    <!-- App Css-->
    <link href="../assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <style type="text/css">
      .logo{
        width: 80%;
        max-width: 100%;
      }
      .page_break { page-break-before: always; }
    </style>
  </head>
  <body style="background: #fff;">
      <div class="row" style="background: #fff;">
        <div class="col-lg-12" style="background: #fff;padding: 0">
          <div class="card" style="background: #fff;">
            <div class="card-body" style="background: #fff; padding: 0">
              <div class="row" style="height: 55px;">
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center">
                  <img src="../images/ezeefit.jpg" alt="logo" class="logo" />
                </div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10" style="padding-left: 150px; padding-top: 0px;">
                  <h5 class="text-left">Ezeefit Modular Furniture Pvt. Ltd.</h5>
                    <p class="text-left" style="margin: 0;font-size: 12px;"><b>Address:  A-611, Crystal Plaza Premises, New Link Road, Andheri (W), Mumbai - 400 053, India</b></p>
                    <p class="text-left" style="margin: 0;font-size: 11px;"><b>
                    Email Id:  purchase@ezeefit.in | ezeefit@ezeefit.in ||
                    Mobile No: 9920968061 || Gst No: 27AADCE6117G1ZT
                      </b>
                    </p>
                </div>
              </div>
              <hr>
              <div class="row" style="height: 100px;">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <address style="font-size: 11px;">
                    <strong>To:</strong>
                    <?php
                    $mysqli->where('id',$invoice['vendor_id']);
                    $vendors = $mysqli->getOne(VENDORS);
                    ?>
                    <b><?=$vendors['company']?><input type="hidden" name="vendor_id" value="<?=$vendors['id']?>"><br>
                    <?=$vendors['address']?>,<br>
                    <?=$vendors['city']?>, <?=$vendors['state']?>, <?=$vendors['country']?> - <?=$vendors['pincode']?><br>
                    GST No: <?=$vendors['gst_no']?><br>
                    Email: <?=$vendors['email']?><br>
                    Moblie No: <?=$vendors['mobile']?>
                    </b>
                  </address>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-left" style="text-align: right; padding-left: 400px">
                  <address class="float-right mt-1 text-left" style="font-size: 11px;">
                    <b>
                      Purchase Id : <?=$invoice['quotation_id']?><br>
                      Purchase Date : <?php echo date('d M Y', strtotime($invoice['quotation_date']))?><br>
                      Delivery Date : <?php echo date('d M Y', strtotime($invoice['delivery_data']))?><br>
                      Delivery Address : <?=$invoice['delivery_add']?><br>
                    </b>
                  </address>
                </div>
              </div>
              <hr>
              <!-- <hr style="margin-top: 0;"> -->
              <div class="table-responsive">
                <h3 class="font-size-15 font-weight-bold">Purchase Order summary</h3>
                <table class="table table-nowrap">
                  <thead>
                    <tr>
                      <th style="font-size: 11px;">No</th>
                      <th style="font-size: 11px;">Products</th>
                      <th style="font-size: 11px;">Size</th>
                      <th style="font-size: 11px;">Matte Size<br>(W X H)</th>
                      <th style="font-size: 11px;">QTY</th>
                      <th style="font-size: 11px;">Sq.Mit</th>
                      <th style="font-size: 11px;">Rates</th>
                      <th style="font-size: 11px;text-align: right;">Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    $grand = '0';
                    $i = '1';
                    foreach ($str_arr as $key => $product_id) {
                      $product_id;
                      $quantity = $qtys[$key];
                      $mysqli->where('id', $product_id);
                      $products = $mysqli->get(PRODUCTS);
                      foreach($products as $pros){
                        extract($pros);
                        $mysqli->where('product_id', $id);
                        $mysqli->where('vendor_id', $invoice['vendor_id']);
                        $rate = $mysqli->getOne(RATES);
                        $total_sqmit = $quantity*$sq_mit;
                        $total = $rate['rates']*$total_sqmit;
                        $total_final = number_format((float)$total, 2, '.', '');
                        $grand+= $total_final;
                      ?>
                    <tr>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$i++?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$product?> (<?=$type?>)</td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$size?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$width?> X <?=$height?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$quantity?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;"><?=$total_sqmit?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;" class="text-center"><?=$rate['rates']?></td>
                      <td style="font-size: 11px;padding-top: 5px;padding-bottom: 5px;" class="text-right"><?=$total_final?></td>
                    </tr>
                    <?php } } ?>
                    <?php $gst = $grand/100*18;
                    $final = $grand+$gst;
                    ?>
                    <tr>
                        <td colspan="6" style="padding: 0"></td>
                        <td style="font-size: 11px;padding: 5; padding-right: 20px;" class="text-left">Sub Total</td>
                        <td style="font-size: 11px;padding: 5; padding-right: 12px;" class="text-right"><?php echo number_format((float)$grand, 2, '.', '');?></td>
                    </tr>
                    <tr>
                        <td colspan="6"></td>
                        <td style="font-size: 11px;padding: 5; padding-right: 12px;" class="text-left">GST (18%)</td>
                        <td style="font-size: 11px;padding: 5; padding-right: 12px;" class="text-right"><?php echo number_format((float)$gst, 2, '.', '');?></td>
                    </tr>
                    <tr>
                        <td colspan="6"></td>
                        <td style="font-size: 11px;padding: 5; padding-right: 12px;" class="text-left">Total</td>
                        <td style="font-size: 11px;padding: 5; padding-right: 12px;" class="text-right"><?php echo number_format((float)$final, 2, '.', '');?></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="table-responsive">
                <table class="table-bordered table-nowrap table-bordered" style="margin-bottom: 0; width:100%">
                  <thead>
                    <tr>
                      <th width="20%" class="text-center" style="font-size: 11px;">Client Company</th>
                      <th width="20%" class="text-center" style="font-size: 11px;">Contact Person</th>
                      <th width="20%" class="text-center" style="font-size: 11px;">Superviser</th>
                      <th width="20%" class="text-center" style="font-size: 11px;">Contractor</th>
                      <th width="20%" class="text-center" style="font-size: 11px;">Approved</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="text-center" style="font-size: 11px;"><b><?=$invoice['client_com']?></b></td>
                      <td class="text-center" style="font-size: 11px;"><b><?=$invoice['contact_person']?></b></td>
                      <td class="text-center" style="font-size: 11px;"><b><?=$invoice['superviser']?></b></td>
                      <td class="text-center" style="font-size: 11px;"><b><?=$invoice['contractor']?></b></td>
                        <?php
                          $mysqli->where('id', $_GET['id']);
                          $getAdmin = $mysqli->getOne(USER);
                        ?>
                      <td class="text-center">
                        <img src="../<?=$getAdmin['admin_sign']?>" width="50px" style="padding-top: 10px">
                        <img src="../<?=$getAdmin['admin_stamp']?>" width="50px" height="auto" style="position: absolute; padding-top: 20px;">
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <hr style="margin-bottom: 0">
              <div class="py-2 mt-3">
                <h3 class="font-size-14 font-weight-bold">Term: </h3>
                <ul>
                  <li class="font-size-11" style="margin-left: 15px;color:#000000;">It is mandatory to put Purchase Order number in all Tax Invoices.</li>
                  <li class="font-size-11" style="margin-left: 15px;color:#000000;">Physical copy of Tax Invoice along with copy of our Purchase Order and copy of Delivery challan is mandatory for release of payment.</li>
                  <li class="font-size-11" style="margin-left: 15px; color: #000000">It is mandatory to deliver goods in Good Quality for release of payment. Payment shall not be made for material received which is inferior in quality or damaged.</li>
                  <li class="font-size-11" style="margin-left: 15px;color:#000000;">Time is of the essence with respect to delivery of the Goods and performance of Services. Goods shall be delivered by the Supplier and Services performed by the applicable Delivery Date. Supplier must immediately notify Buyer if Supplier is likely to be unable to meet a Delivery Date. At any time prior to the Delivery Date, Buyer may, upon notice to Supplier, cancel or change a Purchase Order, or any portion thereof, for any reason, including, without limitation, for the convenience of Buyer or due to failure of Supplier to comply with these terms, unless otherwise noted.</li>
                  <li class="font-size-11" style="margin-left: 15px;color:#000000;">Any query may please be forwarded to our office on above mentioned emails or contact number.</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="page_break"></div>
      <div class="row" style="background: #fff;">
        <?php
          $mysqli->where('id', $invoice['compare_id']);
          $rates = $mysqli->getOne(R_COMPARE);
          $str_arr = preg_split ("/\,/", $rates['product_id']);
          /*print_r($str_arr);*/
          $p_id=explode(" ",$rates['product_id']);
          /*print_r($p_id);*/
          $qtys=explode(",",$rates['qtys']);
          /*print_r($qtys);*/
          $v_id=explode(",",$rates['vendor_id']);
          $totals = explode(",", $rates['totals']);
        ?>
        <div class="col-lg-12" style="background: #fff;padding: 0">
          <div class="card" style="background: #fff;">
            <div class="card-body" style="background: #fff; padding: 0">
              <div class="row" style="height: 55px;">
                <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 text-center">
                  <img src="../images/ezeefit.jpg" alt="logo" class="logo" />
                </div>
                <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10" style="padding-left: 150px; padding-top: 0px;">
                  <h5 class="text-left">Ezeefit Modular Furniture Pvt. Ltd.</h5>
                    <p class="text-left" style="margin: 0;font-size: 12px;"><b>Address:  A-611, Crystal Plaza Premises, New Link Road, Andheri (W), Mumbai - 400 053, India</b></p>
                    <p class="text-left" style="margin: 0;font-size: 11px;"><b>
                    Email Id:  purchase@ezeefit.in | ezeefit@ezeefit.in ||
                    Mobile No: 9920968061 || Gst No: 27AADCE6117G1ZT
                      </b>
                    </p>
                </div>
              </div>
              <hr>
              <div class="row" style="height: 30px;">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                  <address style="font-size: 11px;">
                    <strong>Client Name:</strong><?=$rates['client']?>
                  </address>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 text-left" style="text-align: right; padding-left: 400px">
                  <address class="float-right mt-1 text-left" style="font-size: 11px;">
                   <strong>Approved To:</strong>
                    <?php
                    $mysqli->where('id',$invoice['vendor_id']);
                    $vendors = $mysqli->getOne(VENDORS);
                    ?>
                    <b><?=$vendors['company']?>
                    </b>
                  </address>
                </div>
              </div>
              <hr>
              <!-- <hr style="margin-top: 0;"> -->
              <div class="table-responsive">
                <h3 class="font-size-15 font-weight-bold">Rate Comparison summary</h3>
                <table class="table table-nowrap">
                  <thead>
                    <tr>
                      <th style="font-size: 11px;">Products</th>
                      <th style="font-size: 11px;">Size</th>
                      <th style="font-size: 11px;">Matte Size<br>(W X H)</th>
                      <th style="font-size: 11px;">Qty</th>
                      <th style="font-size: 11px;">Sq.Mit</th>
                      <?php      
                      foreach ($v_id as $key => $ved_id) {
                              $mysqli->where('id', $ved_id);
                              $vendors = $mysqli->get(VENDORS);
                              foreach($vendors as $vendor){
                                $text  = $vendor['company'];
                                $words = explode(" ", $text);
                          ?>
                          <th style="font-size: 11px;">
                            <?=$words[0]?> Rates</th>
                          <th style="font-size: 11px;"><?=$words[0]?> Total</th>
                      <?php } }?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    foreach ($str_arr as $key => $product_id) {
                      $product_id;
                      $quantity = $qtys[$key];
                      /*$vendor_id = $v_id[$key];*/
                    
                    $mysqli->where('id', $product_id);
                    $products = $mysqli->get(PRODUCTS);
                    foreach($products as $pros){
                      extract($pros);
                      $total_sqmit = $sq_mit*$quantity;
                      ?>
                    <tr>
                      <td width="15%" style="font-size: 11px;"><?=$product?><br>(<?=$type?>)</td>
                      <td style="font-size: 11px;"><?=$size?></td>
                      <td style="font-size: 11px;"><?=$width?> X <?=$height?></td>
                      <td width="5%" style="font-size: 11px;"><?=$quantity?></td>
                      <td style="font-size: 11px;"><?=$total_sqmit?></td>
                      <?php 
                      foreach ($v_id as $key => $ved_id) {
                        $mysqli->where('id', $ved_id);
                        $vendorss = $mysqli->get(VENDORS);
                        foreach ($vendorss as $vendor) {
                            $mysqli->where('vendor_id', $vendor['id']);
                        $mysqli->where('product_id', $id);
                        $vend = $mysqli->getOne(RATES);
                        /*$mysqli->where('id', $rate['vendor_id']);
                        $vendor = $mysqli->getOne(VENDORS);*/
                        $i = '1';
                        /*$total_rate=$total_sqmit*$vend['rates'];
                        $all_tol+= $total_rate;*/
                        $total_rate = $total_sqmit*$vend['rates'];
                        /*$all_tol+= $total_rate;*/
                      ?>
                      <td style="font-size: 11px;"><?=$vend['rates']?></td>
                      <td style="font-size: 11px;"><?=round($total_rate)?></td>
                      <?php } }?>
                    </tr>
                    <?php } } ?>
                    <tfoot>
                        <tr>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;">Total:</td>
                            <td style="font-size: 11px;"></td>
                            <?php      
                                foreach ($totals as $key => $total) {
                            ?>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;"><?=$total?></td>
                            <?php }?>
                        </tr>
                        <tr>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;"></td>
                            <td style="font-size: 11px;">Approved to</td>
                            <td style="font-size: 11px;"></td>
                            <?php foreach ($v_id as $key => $ved_id) {
                            ?>
                            <td colspan="2" style="font-size: 11px;text-align: center;">
                              <?php
                              if ($ved_id == $invoice['vendor_id']) {
                                $mysqli->where('id', $_GET['id']);
                                $getAdmin = $mysqli->getOne(USER);
                              ?>
                              <img src="../<?=$getAdmin['admin_sign']?>" width="50px" style="padding-top: 10px">
                              <img src="../<?=$getAdmin['admin_stamp']?>" width="50px" height="auto" style="position: absolute; padding-top: 20px;padding-right: 100px">
                              <?php } ?>
                            </td>
                            <?php } ?>
                        </tr>
                    </tfoot>
                  </tbody>
                </table>
              </div>
              <hr style="margin-bottom: 20px">
              <div class="table-responsive">
                <table class="table-bordered table-nowrap table-bordered" style="margin-bottom: 0; width:100%">
                  <thead>
                    <tr>
                      <th width="20%" class="text-center" style="font-size: 11px;text-align: center;">Superviser</th>
                      <th width="20%" class="text-center" style="font-size: 11px;text-align: center;">Contractor</th>
                      <th width="20%" class="text-center" style="font-size: 11px;text-align: center;">Ordered By</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="text-center" style="font-size: 11px;"><b><?=$rates['supervisor']?></b></td>
                      <td class="text-center" style="font-size: 11px;"><b><?=$rates['contractor']?></b></td>
                      <td class="text-center" style="font-size: 11px;"><b><?=$rates['ordered_by']?></b></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    <!-- end row -->
  <!-- JAVASCRIPT -->
  <script src="../assets/libs/jquery/jquery.min.js"></script>
  <script src="../assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
<script type="text/javascript">
    $('table tfoot td').each(function(index) {
    var total = 0;
    $('tbody tr').each(function() {
        total += +$('td', this).eq(index).text(); //+ will convert string to number
    });
    $(this).text();
})
</script>