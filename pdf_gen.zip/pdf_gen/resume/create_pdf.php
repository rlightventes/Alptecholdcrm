<?php include '../common/common.php';?>
<?php
// Include autoloader 
require_once 'dompdf/autoload.inc.php'; 
 
// Reference the Dompdf namespace 
use Dompdf\Dompdf; 
 
// Instantiate and use the dompdf class 
$dompdf = new Dompdf();

  $get_id = base64_decode($_GET['hr']);
            $mysqli->where('id', $get_id);
            $get_requirt = $mysqli->getOne(JOB_SEEKER);
            extract($get_requirt);
            if(!empty($profileImg)){
                $imgName = $profileImg;
            }else{
                 $imgName = 'no-img.jpg';
            }
            $mysqli->where('id', $assigned);
            $getSale = $mysqli->getOne(SALES);
            $mysqli->where('id', $company_id);
            $getClient = $mysqli->getOne(CLIENT);
            $output = '<!DOCTYPE html>
              <html>
                <head>
                  <meta charset="utf-8">
                  <title></title>
                </head>
                <style>
@font-face {
  font-family: "OpenSans-Regular";
  font-style: normal;
  font-weight: normal;
}
</style>

                <body style="border:1px solid #e7e7e7; background:#f7f7f7; padding:20px; font-family:Helvetica; font-size:12px">
                <div style="background:#fff; ">
                  <h3 style="margin: 0px;text-align:center; background:#3c8dbc; color:#fff; padding:10px 0">RESUME</h3>
                  
                  <table style="width:90%; margin: 20px auto; line-height:20px" cellspacing="0" cellpadding="0">
                    <tr>
                      <th width="20%" style="text-align:left; padding-left:20px; padding-bottom:5px">Name: </th>
                      <td width="30%" style="text-align:left; text-transform:capitalize; padding-left:20px">'.$name.'</td>
                      <td width="20%" rowspan="5" style="text-align:left;"><img src="../profile/'.$imgName.'" width="150"></td>
.                   </tr>
                    <tr>
                      <th width="20%" style="text-align:left; padding-left:20px; padding-bottom:5px">Gender: </th>
                      <td width="30%" style="text-align:left; padding-left:20px">'.$gender.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; padding-left:20px; padding-bottom:5px">Date of Birth: </th>
                      <td width="30%" style="text-align:left; padding-left:20px">'.$dob.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; padding-left:20px; padding-bottom:5px">Marital Status: </th>
                      <td width="30%" style="text-align:left; padding-left:20px">'.$marital_sts.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; padding-left:20px; padding-bottom:20px">Caste: </th>
                      <td width="30%" style="text-align:left; padding-left:20px; padding-bottom:20px">'.$caste.'</td>
                     
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left; background:#e3e3e3;  border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc; padding:0">ADDRESS INFORMATION</h4></th>
                        <td style="text-align:left; background:#e3e3e3; border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px; vertical-align:top">Address: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3;  padding-left:20px;">'.$address.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Pincode: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$pincode.'</td>
                     
                    </tr>
                     <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Line: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$line.'</td>
                     
                    </tr>
                     <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Native: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$native.'</td>
                     
                    </tr>
                    
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3; border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">Preferred City: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3;border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">'.$pre_city.'</td>
                     
                    </tr>
                    <tr>
                        <td colspan="3"><br/></td>
                    </tr>
                     <tr>
                        <th colspan="2" style="text-align:left; background:#e3e3e3;  border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">EDUCATION INFORMATION</h4></th>
                        <td style="text-align:left; background:#e3e3e3; border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px; vertical-align:top">Qualification: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$qualif.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; vertical-align:top; background:#e3e3e3; border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">Skills: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3;border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">'.$skills.'</td>
                     
                    </tr>
                    <tr>
                        <td colspan="3"><br/></td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left; background:#e3e3e3;  border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">LAST WORKING INFORMATION</h4></th>
                        <td style="text-align:left; background:#e3e3e3; border-top:#d5d5d5 1px solid; padding-top:20px; padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Company Name: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$comp_name.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Designation: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$designatioin.'</td>
                     
                    </tr>
                   
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Job Type: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$job_type.'</td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Salary : </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$salary.'</td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px;">Experience: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$experience.'</td>
                     
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3;  padding-left:20px; vertical-align:top">Work  Experience: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3; padding-left:20px;">'.$work_experience.'</td>
                    </tr>
                    <tr>
                      <th width="20%" style="text-align:left; background:#e3e3e3; border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">Salary Expectation: </th>
                      <td width="30%" colspan="2" style="text-align:left; background:#e3e3e3;border-bottom:#d5d5d5 1px solid; padding-bottom:20px;  padding-left:20px;">'.$expectation.'</td>
                     
                    </tr>
                    <tr>
                        <td colspan="3"><br/> </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left;  padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">FAMILY BACKGROUND</h4></th>
                        <td style="text-align:left;  padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align:left;  padding-bottom:5px; padding-left:20px;">'.$family_bg.'</td>
                    </tr>
                    <tr>
                        <td colspan="3"><br/> </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left;  padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">TYPE OF WORK REQUIRED</h4></th>
                        <td style="text-align:left;  padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align:left;  padding-bottom:5px; padding-left:20px;">'.$work_required.'</td>
                    </tr>
                    <tr>
                        <td colspan="3"><br/> </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left;  padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">PET FRIENDLY</h4></th>
                        <td style="text-align:left;  padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align:left;  padding-bottom:5px; padding-left:20px;">'.$pet_frnd.'</td>
                    </tr>
                     <tr>
                        <td colspan="3"><br/> </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left;  padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">VACCINATION DETAILS</h4></th>
                        <td style="text-align:left;  padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                   
                    <tr>
                        <td colspan="3" style="text-align:left;  padding-bottom:5px; padding-left:20px;">'.$vaccination.'</td>
                    </tr>
                     <tr>
                        <td colspan="3"><br/> </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="text-align:left;  padding-bottom:5px; padding-left:20px;"><h4 style="margin:0px; border-bottom:1px solid #3c8dbc;">OTHER INFORMATION</h4></th>
                        <td style="text-align:left;  padding-bottom:5px; padding-left:20px;"></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align:left;  padding-bottom:5px; padding-left:20px;">'.$comment.'</td>
                    <tr>
                    <tr>
                        <td colspan="3"><br/></td>
                    </tr>
                  </table>    </div>
                </body>
              </html>';
             
              // Load HTML content 
$dompdf->loadHtml($output); 
 
// (Optional) Setup the paper size and orientation 
$dompdf->setPaper('A4', 'portrait'); 
 
// Render the HTML as PDF 
$dompdf->render(); 
 
// Output the generated PDF to Browser 
$dompdf->stream();

// Output the generated PDF (1 = download and 0 = preview) 
$dompdf->stream("codexworld", array("Attachment" => 0));
    ?>