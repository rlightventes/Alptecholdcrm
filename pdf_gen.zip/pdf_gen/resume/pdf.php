<?php include '../common/common.php';?>
<?php
  $get_id = base64_decode($_GET['hr']);
  $mysqli->where('id', $get_id);
  $get_requirt = $mysqli->getOne(JOB_SEEKER);
  extract($get_requirt);
  $mysqli->where('id', $assigned);
  $getSale = $mysqli->getOne(SALES);
  $mysqli->where('id', $company_id);
  $getClient = $mysqli->getOne(CLIENT);
?>

<!DOCTYPE html>
              <html>
                <head>
                  <meta charset="utf-8">
                  <title></title>
                </head>
                <body style="border:1px solid #666; padding:20px; font-family:Arial, Helvetica, sans-serif;">
                  <h3 style="margin: 0px;text-align:center"><u>RESUME</u></h3>
                  <h2 style="margin: 0px;text-transform: uppercase;text-align:center;padding-top:30px;"><?=$name?></h2>
                  <h4 style="border-bottom:1px solid #666; font-weight:bold; letter-spacing:2px; padding:10px 0;text-align:center">PERSONAL INFORMATION</h4>
                  <img src="https://hireamaids.com/erp/profile/no-img.jpg">
                  <table style="width:100%">
                    <tr>
                      <td width="20%" style="text-align:left;">Gender: </td>
                      <td width="30%" style="text-align:left;"><?=$gender?></td>
                      <td width="20%" style="text-align:left;">Date of Birth: </td>
                      <td width="30%" style="text-align:left;"><?=date('d M Y', strtotime($dob))?></td>
                    </tr>
                    <tr>
                      <td width="20%" style="text-align:left;">Marital Status: </td>
                      <td width="30%" style="text-align:left;"><?=$marital_sts?></td>
                      <td width="20%" style="text-align:left;">Caste: </td>
                      <td width="30%" style="text-align:left;"><?=$caste?></td>
                    </tr>
                  </table>
                  <h4 style="border-bottom:1px solid #666; font-weight:bold; letter-spacing:2px; padding:10px 0;text-align:center">ADDRESS INFORMATION</h4>
                  <table style="width:100%">
                    <tr>
                      <td width="20%" style="text-align:left;">Address: </td>
                      <td width="30%" colspan="3" style="text-align:left; padding-bottom:10px;"><?=$address?>, <?=$pincode?></td>
                    </tr>
                    <tr>
                      <td width="20%" style="text-align:left;">Location: </td>
                      <td width="30%" style="text-align:left;"><?=$location?></td>
                      <td width="20%" style="text-align:left;">Line: </td>
                      <td width="30%" style="text-align:left;"><?=$line?></td>
                    </tr>
                  </table>
                  <h4 style="border-bottom:1px solid #666; font-weight:bold; letter-spacing:2px; padding:10px 0;text-align:center">EDUCATION INFORMATION</h4>
                  <table style="width:100%">
                    <tr>
                      <td width="20%" style="text-align:left;">Qualification: </td>
                      <td width="30%" style="text-align:left;"><?=$qualif?></td>
                      <td width="20%" style="text-align:left;">Skills: </td>
                      <td width="30%" style="text-align:left;"><?=$skills?></td>
                    </tr>
                  </table>
                  <h4 style="border-bottom:1px solid #666; font-weight:bold; letter-spacing:2px; padding:10px 0;text-align:center">LAST WORKING INFORMATION</h4>
                  <table style="width:100%">
                    <tr>
                      <td width="20%" style="text-align:left;">Experience: </td>
                      <td width="30%" style="text-align:left;"><?=$experience?></td>
                      <td width="20%" style="text-align:left;">Job Type: </td>
                      <td width="30%" style="text-align:left;"><?=$job_type?></td>
                    </tr>
                    <tr>
                      <td width="20%" style="text-align:left;">Company Name: </td>
                      <td width="30%" style="text-align:left;"><?=$comp_name?></td>
                      <td width="20%" style="text-align:left;">Designation: </td>
                      <td width="30%" style="text-align:left;"><?php if(empty($designatioin)){echo '-'; }else{ echo $designatioin;}?></td>
                    </tr>
                    <tr>
                      <td width="20%" style="text-align:left;">Salary: </td>
                      <td width="30%" style="text-align:left;"><?php if(empty($salary)){echo '-'; }else{ echo $salary;}?></td>
                    </tr>
                  </table>
                  <?php if(!empty($comment)){ ?>
                  <h4 style="border-bottom:1px solid #666; font-weight:bold; letter-spacing:2px; padding:10px 0;text-align:center">OTHER INFORMATION</h4>
                  <p><?=$comment?></p>
                  <?php }?>
                </body>
              </html>