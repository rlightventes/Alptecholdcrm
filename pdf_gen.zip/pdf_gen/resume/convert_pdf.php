<?php include '../common/common.php';

//inckude autoloader

require_once 'dompdf/autoload.inc.php';

  $get_id = base64_decode($_GET['hr']);
  $mysqli->where('id', $get_id);
  $get_requirt = $mysqli->getOne(JOB_SEEKER);
  extract($get_requirt);
  $mysqli->where('id', $assigned);
  $getSale = $mysqli->getOne(SALES);
  $mysqli->where('id', $company_id);
  $getClient = $mysqli->getOne(CLIENT);


  $data = array('pdf' => '1');
  $mysqli->where('id', $get_id);
  $update = $mysqli->update(JOB_SEEKER, $data);



// reference the Dompdf namespace
use Dompdf\Dompdf;

//Instantiate dompdf class
$dompdf = new Dompdf();


 $dompdf->loadHtml($aData['html']);
    $dompdf->set_option('isRemoteEnabled', TRUE);
    
//load HTML content
// $dompdf->loadHtml('');

//load content from HTML file
$html = file_get_contents("http://hireamaids.com/erp/resume/create_pdf.php?hr=".$_GET['hr']);
$dompdf->loadHtml($html);
// $dompdf->setFont('Helvetica', '', 12);

$dompdf->setPaper('A4', 'portal');
$dompdf->render();
$output = $dompdf->output();
//file location where we need to store pdf
file_put_contents('../resume_pdf/'.$name.'.pdf', $output);
//Output thegenerated PDF
$dompdf->stream('coderworld', array('Attachment'=> 0));
header('location: ../candidates_list.php');
echo "<script>window.location.href='../candidates_list.php';</script>";
?>