<?php
namespace Dompdf;
require_once 'dompdf/autoload.inc.php';

$dompdf = new Dompdf(); 
$dompdf->loadHtml('<html><body><b>Resr</b></body></html>');

$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$output = $dompdf->output();
//file location where we need to store pdf
file_put_contents('pdf/corel.pdf', $output);

$dompdf->stream("",array("Attachment" => false));
header('location: pdf/corel.pdf');
?>